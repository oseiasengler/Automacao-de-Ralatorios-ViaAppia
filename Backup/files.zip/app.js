/* ============================================================
   Inventário de Drenagem — app de campo offline-first
   Armazena local em IndexedDB; sincroniza em lote com /sync.
   ============================================================ */
"use strict";

const CAT = window.CATALOGO;
const DB_NAME = "drenagem", DB_VER = 1;
const ESTADOS = CAT.estados_conservacao;
const TIPOS = CAT.dispositivos;
const tipoPorChave = Object.fromEntries(TIPOS.map(t => [t.tipo, t]));
const CATEGORIAS = [...new Set(TIPOS.map(t => t.categoria))];

let db, estado = {
  id: null, sentido: "crescente", lado: "BD", estadoConserv: null,
  gps1: null, gps2: null, fotos: []
};

/* ---------- IndexedDB ---------- */
function openDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB_NAME, DB_VER);
    r.onupgradeneeded = e => {
      const d = e.target.result;
      if (!d.objectStoreNames.contains("registros"))
        d.createObjectStore("registros", { keyPath: "id" });
      if (!d.objectStoreNames.contains("config"))
        d.createObjectStore("config", { keyPath: "k" });
    };
    r.onsuccess = e => res(e.target.result);
    r.onerror = e => rej(e.target.error);
  });
}
function tx(store, mode = "readonly") { return db.transaction(store, mode).objectStore(store); }
function idbPut(store, v) { return new Promise((res, rej) => { const r = tx(store, "readwrite").put(v); r.onsuccess = res; r.onerror = () => rej(r.error); }); }
function idbGet(store, k) { return new Promise((res, rej) => { const r = tx(store).get(k); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
function idbAll(store) { return new Promise((res, rej) => { const r = tx(store).getAll(); r.onsuccess = () => res(r.result || []); r.onerror = () => rej(r.error); }); }
function idbDel(store, k) { return new Promise((res, rej) => { const r = tx(store, "readwrite").delete(k); r.onsuccess = res; r.onerror = () => rej(r.error); }); }

/* ---------- util ---------- */
const $ = s => document.querySelector(s);
const uuid = () => (crypto.randomUUID ? crypto.randomUUID()
  : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0; return (c === "x" ? r : (r & 3 | 8)).toString(16);
  }));
function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove("show"), 2600); }
function seg(container, opcoes, atual, onPick, rotulos) {
  container.innerHTML = "";
  opcoes.forEach(v => {
    const b = document.createElement("button"); b.type = "button";
    b.textContent = rotulos ? rotulos[v] : v; b.dataset.v = v;
    if (v === atual) b.classList.add("sel");
    b.onclick = () => { [...container.children].forEach(c => c.classList.remove("sel")); b.classList.add("sel"); onPick(v); };
    container.appendChild(b);
  });
}

/* ---------- montagem do form ---------- */
function initForm() {
  $("#categoria").innerHTML = CATEGORIAS.map(c => `<option value="${c}">${c}</option>`).join("");
  seg($("#segSentido"), ["crescente", "decrescente", "ambos"], estado.sentido, v => estado.sentido = v);
  seg($("#segLado"), ["BE", "BD", "CC", "eixo"], estado.lado, v => estado.lado = v,
    { BE: "Esq.", BD: "Dir.", CC: "Canteiro", eixo: "Eixo" });
  seg($("#segEstado"), ESTADOS, estado.estadoConserv, v => estado.estadoConserv = v);
  $("#data_inspecao").value = new Date().toISOString().slice(0, 10);
  onCategoria();
}
function onCategoria() {
  const cat = $("#categoria").value;
  const lista = TIPOS.filter(t => t.categoria === cat);
  $("#tipo").innerHTML = lista.map(t => `<option value="${t.tipo}">${t.rotulo}</option>`).join("");
  onTipo();
}
function onTipo() {
  const t = tipoPorChave[$("#tipo").value];
  const linear = t.geometria === "linear";
  $("#wrapKmFim").classList.toggle("hidden", !linear);
  $("#wrapGps2").classList.toggle("hidden", !linear);
  $("#lblGps").textContent = linear ? "Coordenada (entrada)" : "Coordenada";
  renderAtributos(t);
}
function renderAtributos(t) {
  const box = $("#atributos"); box.innerHTML = "";
  $("#tituloAtributos").textContent = "Especificações — " + t.rotulo;
  t.atributos.forEach(c => {
    const wrap = document.createElement("div");
    wrap.className = "field"; wrap.dataset.nome = c.nome;
    if (c.depende_de) { wrap.dataset.dependeDe = c.depende_de; wrap.dataset.dependeValor = c.depende_valor; }
    const lab = document.createElement("label");
    lab.textContent = c.rotulo + (c.unidade ? ` (${c.unidade})` : "");
    if (c.obrigatorio) lab.className = "req";
    wrap.appendChild(lab);

    let el;
    if (c.tipo === "enum") {
      el = document.createElement("select");
      el.innerHTML = `<option value="">—</option>` + c.opcoes.map(o => `<option value="${o}">${o}</option>`).join("");
    } else if (c.tipo === "bool") {
      el = document.createElement("select");
      el.innerHTML = `<option value="">—</option><option value="true">Sim</option><option value="false">Não</option>`;
    } else if (c.tipo === "numero") {
      el = document.createElement("input"); el.type = "number"; el.inputMode = "decimal"; el.step = "any";
    } else {
      el = document.createElement("input"); el.type = "text";
    }
    el.id = "attr_" + c.nome; el.dataset.tipo = c.tipo;
    if (c.depende_de) el.addEventListener; // placeholder
    wrap.appendChild(el);
    if (c.ajuda) { const h = document.createElement("div"); h.className = "hint"; h.textContent = c.ajuda; wrap.appendChild(h); }
    box.appendChild(wrap);

    // reavalia campos condicionais quando o campo-pai muda
    el.addEventListener("change", () => aplicaCondicionais(t));
  });
  aplicaCondicionais(t);
}
function aplicaCondicionais(t) {
  t.atributos.forEach(c => {
    if (!c.depende_de) return;
    const pai = $("#attr_" + c.depende_de);
    const wrap = document.querySelector(`#atributos .field[data-nome="${c.nome}"]`);
    if (!pai || !wrap) return;
    wrap.classList.toggle("hidden", String(pai.value) !== c.depende_valor);
  });
}

/* ---------- GPS ---------- */
function capturaGps(n) {
  if (!navigator.geolocation) return toast("GPS indisponível");
  const alvo = $("#gps" + n);
  alvo.innerHTML = "<small>capturando…</small>—";
  navigator.geolocation.getCurrentPosition(p => {
    const { latitude: la, longitude: lo, accuracy: ac } = p.coords;
    const obj = { lat: +la.toFixed(6), lon: +lo.toFixed(6), acc: Math.round(ac) };
    estado["gps" + n] = obj;
    const cls = ac <= 10 ? "acc-ok" : "acc-bad";
    alvo.innerHTML = `<small>±<span class="${cls}">${obj.acc} m</span> de acurácia</small>${obj.lat}, ${obj.lon}`;
  }, err => { alvo.innerHTML = "<small>falhou</small>—"; toast("GPS: " + err.message); },
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
}

/* ---------- fotos (downscale local) ---------- */
function addFoto(input) {
  const file = input.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const max = 1280, sc = Math.min(1, max / Math.max(img.width, img.height));
      const cv = document.createElement("canvas");
      cv.width = img.width * sc; cv.height = img.height * sc;
      cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
      const data = cv.toDataURL("image/jpeg", 0.7);
      const ref = `${(estado.id || "novo")}_${estado.fotos.length + 1}.jpg`;
      estado.fotos.push({ ref, dataUrl: data });
      renderFotos();
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
  input.value = "";
}
function renderFotos() {
  const box = $("#fotos");
  [...box.querySelectorAll("img")].forEach(i => i.remove());
  estado.fotos.forEach((f, i) => {
    const im = document.createElement("img"); im.src = f.dataUrl;
    im.onclick = () => { if (confirm("Remover foto?")) { estado.fotos.splice(i, 1); renderFotos(); } };
    box.insertBefore(im, box.firstChild);
  });
}

/* ---------- salvar ---------- */
function lerAtributos(t) {
  const out = {}; const erros = [];
  t.atributos.forEach(c => {
    const wrap = document.querySelector(`#atributos .field[data-nome="${c.nome}"]`);
    if (wrap && wrap.classList.contains("hidden")) return;          // condicional oculto: ignora
    const el = $("#attr_" + c.nome); if (!el) return;
    let v = el.value;
    if (v === "" || v == null) { if (c.obrigatorio) erros.push(c.rotulo); return; }
    if (c.tipo === "numero") v = Number(v);
    else if (c.tipo === "bool") v = (v === "true");
    out[c.nome] = v;
  });
  return { out, erros };
}
async function salvar() {
  const t = tipoPorChave[$("#tipo").value];
  const rodovia = $("#rodovia").value.trim();
  const kmIni = $("#km_ini").value;
  const erros = [];
  if (!rodovia) erros.push("Rodovia");
  if (kmIni === "") erros.push("km inicial");
  const { out: atributos, erros: errAttr } = lerAtributos(t);
  erros.push(...errAttr);
  if (erros.length) return toast("Faltando: " + erros.join(", "));

  const linear = t.geometria === "linear";
  const reg = {
    id: estado.id || uuid(),
    rodovia, km_ini: Number(kmIni),
    km_fim: (linear && $("#km_fim").value !== "") ? Number($("#km_fim").value) : null,
    sentido: estado.sentido, lado: estado.lado,
    estaca: $("#estaca").value.trim() || null,
    lat_ini: estado.gps1?.lat ?? null, lon_ini: estado.gps1?.lon ?? null,
    lat_fim: linear ? (estado.gps2?.lat ?? null) : null,
    lon_fim: linear ? (estado.gps2?.lon ?? null) : null,
    precisao_gps_m: estado.gps1?.acc ?? null,
    categoria: t.categoria, tipo: t.tipo,
    extensao_m: null,
    atributos,
    estado_conservacao: estado.estadoConserv,
    data_inspecao: $("#data_inspecao").value || null,
    inspetor: $("#inspetor").value.trim() || null,
    observacoes: $("#observacoes").value.trim() || null,
    fotos: estado.fotos,                          // {ref,dataUrl} local
    ncs: [],
    updated_at: new Date().toISOString(),
    _sync: "pendente",
  };
  await idbPut("registros", reg);
  toast(estado.id ? "Atualizado" : "Salvo offline ✓");
  limparForm();
  await atualizaBadge();
}

function limparForm() {
  estado = { id: null, sentido: "crescente", lado: "BD", estadoConserv: null, gps1: null, gps2: null, fotos: [] };
  $("#rodovia").value = ""; $("#km_ini").value = ""; $("#km_fim").value = "";
  $("#estaca").value = ""; $("#inspetor").value = ""; $("#observacoes").value = "";
  $("#gps1").innerHTML = "<small>sem captura</small>—";
  $("#gps2").innerHTML = "<small>sem captura</small>—";
  $("#btnSalvar").textContent = "Salvar offline";
  initForm(); renderFotos();
}

/* ---------- lista / edição ---------- */
const ICONE = { superficial: "▽", profunda: "⤓", transversal: "⊟" };
async function renderLista() {
  const regs = (await idbAll("registros")).sort((a, b) => b.updated_at.localeCompare(a.updated_at));
  const w = $("#listaWrap");
  if (!regs.length) { w.innerHTML = `<div class="empty"><div class="big">▽</div>Nenhum dispositivo coletado ainda.<br>Vá em <b>Novo</b> e comece o inventário.</div>`; return; }
  w.innerHTML = regs.map(r => {
    const t = tipoPorChave[r.tipo];
    const km = r.km_fim != null ? `km ${r.km_ini}–${r.km_fim}` : `km ${r.km_ini}`;
    const cls = r._sync === "sincronizado" ? "sync" : "pend";
    return `<div class="item" onclick="editar('${r.id}')">
      <div class="ico">${ICONE[r.categoria] || "•"}</div>
      <div class="meta"><b>${t ? t.rotulo : r.tipo}</b>
        <span>${r.rodovia} · ${km} · ${r.lado}${r.estado_conservacao ? " · " + r.estado_conservacao : ""}</span></div>
      <span class="pill ${cls}">${r._sync === "sincronizado" ? "sync" : "pendente"}</span>
    </div>`;
  }).join("");
}
async function editar(id) {
  const r = await idbGet("registros", id); if (!r) return;
  setTab("form");
  estado = { id: r.id, sentido: r.sentido, lado: r.lado, estadoConserv: r.estado_conservacao,
    gps1: r.lat_ini != null ? { lat: r.lat_ini, lon: r.lon_ini, acc: r.precisao_gps_m } : null,
    gps2: r.lat_fim != null ? { lat: r.lat_fim, lon: r.lon_fim, acc: null } : null,
    fotos: r.fotos || [] };
  $("#categoria").value = r.categoria; onCategoria();
  $("#tipo").value = r.tipo; onTipo();
  $("#rodovia").value = r.rodovia; $("#km_ini").value = r.km_ini;
  $("#km_fim").value = r.km_fim ?? ""; $("#estaca").value = r.estaca ?? "";
  $("#inspetor").value = r.inspetor ?? ""; $("#observacoes").value = r.observacoes ?? "";
  $("#data_inspecao").value = r.data_inspecao ?? "";
  initSegFromState();
  Object.entries(r.atributos || {}).forEach(([k, v]) => { const el = $("#attr_" + k); if (el) el.value = (typeof v === "boolean") ? String(v) : v; });
  aplicaCondicionais(tipoPorChave[r.tipo]);
  if (estado.gps1) $("#gps1").innerHTML = `<small>±${estado.gps1.acc ?? "?"} m</small>${estado.gps1.lat}, ${estado.gps1.lon}`;
  if (estado.gps2) $("#gps2").innerHTML = `<small>saída</small>${estado.gps2.lat}, ${estado.gps2.lon}`;
  renderFotos();
  $("#btnSalvar").textContent = "Atualizar";
  // botão apagar via observação longa
  if (!$("#btnDel")) { const b = document.createElement("button"); b.id = "btnDel"; b.className = "btn ghost"; b.textContent = "🗑"; b.onclick = () => apagar(r.id); $("#barForm").insertBefore(b, $("#btnSalvar")); }
}
function initSegFromState() {
  seg($("#segSentido"), ["crescente", "decrescente", "ambos"], estado.sentido, v => estado.sentido = v);
  seg($("#segLado"), ["BE", "BD", "CC", "eixo"], estado.lado, v => estado.lado = v, { BE: "Esq.", BD: "Dir.", CC: "Canteiro", eixo: "Eixo" });
  seg($("#segEstado"), ESTADOS, estado.estadoConserv, v => estado.estadoConserv = v);
}
async function apagar(id) {
  if (!confirm("Apagar este dispositivo?")) return;
  await idbDel("registros", id); toast("Apagado"); $("#btnDel")?.remove();
  limparForm(); setTab("lista"); renderLista(); atualizaBadge();
}

/* ---------- sync ---------- */
async function getBackend() {
  const c = await idbGet("config", "backend");
  return c?.v || "";
}
async function sincronizar() {
  let url = await getBackend();
  if (!url) {
    url = prompt("URL do backend (ex.: https://api.suarodovia.com.br):", "http://localhost:8000");
    if (!url) return;
    await idbPut("config", { k: "backend", v: url.replace(/\/$/, "") });
    url = url.replace(/\/$/, "");
  }
  if (!navigator.onLine) return toast("Sem conexão — tente quando tiver rede");

  const cfgSync = await idbGet("config", "last_sync");
  const last_sync = cfgSync?.v || null;
  const todos = await idbAll("registros");
  const pendentes = todos.filter(r => r._sync !== "sincronizado");

  // payload: tira o binário das fotos (envia só refs nesta versão)
  const registros = pendentes.map(r => ({ ...r, fotos: (r.fotos || []).map(f => f.ref || f), _sync: undefined }));

  $("#btnSync").disabled = true; $("#btnSync").textContent = "Sincronizando…";
  try {
    const resp = await fetch(url + "/sync", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ last_sync, registros }),
    });
    if (!resp.ok) throw new Error("HTTP " + resp.status);
    const j = await resp.json();

    // marca enviados como sincronizados (mantém fotos locais)
    for (const r of pendentes) { r._sync = "sincronizado"; await idbPut("registros", r); }

    // aplica mudanças vindas do servidor (outros aparelhos)
    for (const sv of (j.registros || [])) {
      const local = await idbGet("registros", sv.id);
      if (sv.deleted) { await idbDel("registros", sv.id); continue; }
      const fotosLocais = local?.fotos || [];
      await idbPut("registros", { ...sv, fotos: fotosLocais, _sync: "sincronizado" });
    }
    await idbPut("config", { k: "last_sync", v: j.server_time });
    toast(`Sync ✓  enviados ${j.aplicados} · recebidos ${(j.registros || []).length}`);
    renderLista(); atualizaBadge();
  } catch (e) {
    toast("Falha no sync: " + e.message);
  } finally {
    $("#btnSync").disabled = false; $("#btnSync").textContent = "Sincronizar";
  }
}

/* ---------- export GeoJSON local ---------- */
async function exportGeoJSON() {
  const regs = (await idbAll("registros")).filter(r => r.lat_ini != null);
  if (!regs.length) return toast("Nada georreferenciado pra exportar");
  const feats = regs.map(r => {
    const geom = (r.lat_fim != null)
      ? { type: "LineString", coordinates: [[r.lon_ini, r.lat_ini], [r.lon_fim, r.lat_fim]] }
      : { type: "Point", coordinates: [r.lon_ini, r.lat_ini] };
    return { type: "Feature", geometry: geom, properties: {
      id: r.id, rodovia: r.rodovia, km_ini: r.km_ini, km_fim: r.km_fim, lado: r.lado,
      categoria: r.categoria, tipo: r.tipo, estado: r.estado_conservacao, ...r.atributos } };
  });
  const fc = { type: "FeatureCollection", features: feats };
  const blob = new Blob([JSON.stringify(fc, null, 2)], { type: "application/geo+json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `drenagem_${new Date().toISOString().slice(0, 10)}.geojson`;
  a.click(); URL.revokeObjectURL(a.href);
  toast(`Exportado ${feats.length} feições`);
}

/* ---------- navegação / status ---------- */
function setTab(tab) {
  document.querySelectorAll("nav.tabs button").forEach(b => b.classList.toggle("sel", b.dataset.tab === tab));
  $("#tab-form").classList.toggle("hidden", tab !== "form");
  $("#tab-lista").classList.toggle("hidden", tab !== "lista");
  $("#barForm").classList.toggle("hidden", tab !== "form");
  $("#barLista").classList.toggle("hidden", tab !== "lista");
  if (tab === "lista") renderLista();
  if (tab === "form" && !estado.id) $("#btnDel")?.remove();
}
async function atualizaBadge() {
  const regs = await idbAll("registros");
  const n = regs.filter(r => r._sync !== "sincronizado").length;
  const b = $("#pend"); b.textContent = n; b.classList.toggle("zero", n === 0);
}
function netStatus() {
  const on = navigator.onLine;
  $("#netDot").classList.toggle("on", on);
  $("#netTxt").textContent = on ? "online" : "offline";
}

/* ---------- boot ---------- */
(async function () {
  db = await openDB();
  initForm();
  netStatus();
  await atualizaBadge();
  window.addEventListener("online", netStatus);
  window.addEventListener("offline", netStatus);
  if ("serviceWorker" in navigator) {
    try { await navigator.serviceWorker.register("sw.js"); } catch (e) { /* file:// não suporta SW */ }
  }
})();
