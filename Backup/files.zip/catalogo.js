// GERADO POR catalogo_dispositivos.py — não editar à mão
window.CATALOGO = {
  "estados_conservacao": [
    "bom",
    "regular",
    "ruim",
    "critico"
  ],
  "dispositivos": [
    {
      "tipo": "canaleta",
      "rotulo": "Canaleta",
      "categoria": "superficial",
      "geometria": "linear",
      "atributos": [
        {
          "nome": "secao",
          "rotulo": "Seção",
          "tipo": "enum",
          "obrigatorio": true,
          "unidade": null,
          "opcoes": [
            "triangular",
            "trapezoidal",
            "retangular",
            "meia_cana"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material",
          "rotulo": "Material",
          "tipo": "enum",
          "obrigatorio": true,
          "unidade": null,
          "opcoes": [
            "concreto",
            "grama",
            "solo",
            "pead",
            "alvenaria",
            "pedra_argamassada"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "largura_cm",
          "rotulo": "Largura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "altura_cm",
          "rotulo": "Altura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "sarjeta",
      "rotulo": "Sarjeta",
      "categoria": "superficial",
      "geometria": "linear",
      "atributos": [
        {
          "nome": "posicao",
          "rotulo": "Posição",
          "tipo": "enum",
          "obrigatorio": true,
          "unidade": null,
          "opcoes": [
            "corte",
            "aterro",
            "canteiro_central"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "secao",
          "rotulo": "Seção",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "triangular",
            "trapezoidal",
            "retangular",
            "meia_cana"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material",
          "rotulo": "Material",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "concreto",
            "grama",
            "solo",
            "pead",
            "alvenaria",
            "pedra_argamassada"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "largura_cm",
          "rotulo": "Largura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "altura_cm",
          "rotulo": "Altura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "valeta_protecao",
      "rotulo": "Valeta de proteção",
      "categoria": "superficial",
      "geometria": "linear",
      "atributos": [
        {
          "nome": "posicao",
          "rotulo": "Posição",
          "tipo": "enum",
          "obrigatorio": true,
          "unidade": null,
          "opcoes": [
            "crista_corte",
            "pe_aterro",
            "banqueta"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "secao",
          "rotulo": "Seção",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "triangular",
            "trapezoidal",
            "retangular",
            "meia_cana"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material",
          "rotulo": "Material",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "concreto",
            "grama",
            "solo",
            "pead",
            "alvenaria",
            "pedra_argamassada"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "largura_cm",
          "rotulo": "Largura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "profundidade_cm",
          "rotulo": "Profundidade",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "meio_fio",
      "rotulo": "Meio-fio",
      "categoria": "superficial",
      "geometria": "linear",
      "atributos": [
        {
          "nome": "tipo_mf",
          "rotulo": "Tipo",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "simples",
            "conjugado_sarjeta"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material",
          "rotulo": "Material",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "concreto",
            "pre_moldado"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "altura_cm",
          "rotulo": "Altura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "descida_dagua",
      "rotulo": "Descida d'água",
      "categoria": "superficial",
      "geometria": "linear",
      "atributos": [
        {
          "nome": "tipo_descida",
          "rotulo": "Tipo",
          "tipo": "enum",
          "obrigatorio": true,
          "unidade": null,
          "opcoes": [
            "rapida",
            "degraus"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": "'degraus' = escada hidráulica",
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material",
          "rotulo": "Material",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "concreto",
            "pre_moldado",
            "alvenaria"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "largura_cm",
          "rotulo": "Largura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "n_degraus",
          "rotulo": "Nº de degraus",
          "tipo": "numero",
          "obrigatorio": true,
          "unidade": null,
          "opcoes": [],
          "minimo": 1,
          "maximo": null,
          "ajuda": null,
          "depende_de": "tipo_descida",
          "depende_valor": "degraus"
        },
        {
          "nome": "altura_espelho_cm",
          "rotulo": "Altura do espelho",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": "tipo_descida",
          "depende_valor": "degraus"
        },
        {
          "nome": "tem_dissipador_saida",
          "rotulo": "Dissipador na saída?",
          "tipo": "bool",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "dissipador_energia",
      "rotulo": "Dissipador de energia",
      "categoria": "superficial",
      "geometria": "pontual",
      "atributos": [
        {
          "nome": "tipo_dissipador",
          "rotulo": "Tipo",
          "tipo": "enum",
          "obrigatorio": true,
          "unidade": null,
          "opcoes": [
            "bacia",
            "enrocamento",
            "blocos",
            "escalonado"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "comprimento_cm",
          "rotulo": "Comprimento",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "largura_cm",
          "rotulo": "Largura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "caixa_coletora",
      "rotulo": "Caixa coletora / ligação",
      "categoria": "superficial",
      "geometria": "pontual",
      "atributos": [
        {
          "nome": "funcao",
          "rotulo": "Função",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "coletora",
            "ligacao",
            "passagem"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "largura_cm",
          "rotulo": "Largura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "comprimento_cm",
          "rotulo": "Comprimento",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "profundidade_cm",
          "rotulo": "Profundidade",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "tem_grelha",
          "rotulo": "Tem grelha?",
          "tipo": "bool",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "saida_dagua",
      "rotulo": "Saída/entrada d'água",
      "categoria": "superficial",
      "geometria": "pontual",
      "atributos": [
        {
          "nome": "funcao",
          "rotulo": "Função",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "saida",
            "entrada"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material",
          "rotulo": "Material",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "concreto",
            "alvenaria"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "largura_cm",
          "rotulo": "Largura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "dreno_longitudinal",
      "rotulo": "Dreno longitudinal",
      "categoria": "profunda",
      "geometria": "linear",
      "atributos": [
        {
          "nome": "classe",
          "rotulo": "Classe",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "profundo",
            "raso_pavimento"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "diametro_tubo_mm",
          "rotulo": "Ø tubo",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "mm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material_tubo",
          "rotulo": "Material do tubo",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "concreto",
            "pead",
            "pvc",
            "metalico"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "profundidade_cm",
          "rotulo": "Profundidade",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material_filtrante",
          "rotulo": "Material filtrante",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "brita",
            "areia",
            "geotextil",
            "misto"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "espinha_peixe",
      "rotulo": "Dreno espinha-de-peixe",
      "categoria": "profunda",
      "geometria": "linear",
      "atributos": [
        {
          "nome": "diametro_tubo_mm",
          "rotulo": "Ø tubo",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "mm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "profundidade_cm",
          "rotulo": "Profundidade",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "espacamento_m",
          "rotulo": "Espaçamento entre ramos",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "m",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "dhp",
      "rotulo": "Dreno sub-horizontal (DHP)",
      "categoria": "profunda",
      "geometria": "pontual",
      "atributos": [
        {
          "nome": "diametro_mm",
          "rotulo": "Ø",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "mm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "comprimento_m",
          "rotulo": "Comprimento",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "m",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "inclinacao_graus",
          "rotulo": "Inclinação",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "°",
          "opcoes": [],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "colchao_drenante",
      "rotulo": "Colchão drenante",
      "categoria": "profunda",
      "geometria": "linear",
      "atributos": [
        {
          "nome": "espessura_cm",
          "rotulo": "Espessura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material",
          "rotulo": "Material",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "brita",
            "areia",
            "misto"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "bueiro_tubular",
      "rotulo": "Bueiro tubular (BSTC/BDTC/BTTC)",
      "categoria": "transversal",
      "geometria": "pontual",
      "atributos": [
        {
          "nome": "n_linhas",
          "rotulo": "Nº de linhas",
          "tipo": "enum",
          "obrigatorio": true,
          "unidade": null,
          "opcoes": [
            "1",
            "2",
            "3"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": "1=simples, 2=duplo, 3=triplo",
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "diametro_mm",
          "rotulo": "Ø",
          "tipo": "numero",
          "obrigatorio": true,
          "unidade": "mm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material",
          "rotulo": "Material",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "concreto",
            "metalico",
            "pead"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "tem_ala",
          "rotulo": "Tem ala (asa)?",
          "tipo": "bool",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "tem_dissipador_saida",
          "rotulo": "Dissipador na saída?",
          "tipo": "bool",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "obstrucao_pct",
          "rotulo": "Obstrução da seção",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "%",
          "opcoes": [],
          "minimo": 0,
          "maximo": 100,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "bueiro_celular",
      "rotulo": "Bueiro celular (BSCC/BDCC)",
      "categoria": "transversal",
      "geometria": "pontual",
      "atributos": [
        {
          "nome": "n_celulas",
          "rotulo": "Nº de células",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "1",
            "2",
            "3"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "largura_cm",
          "rotulo": "Largura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "altura_cm",
          "rotulo": "Altura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material",
          "rotulo": "Material",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "concreto"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "tem_ala",
          "rotulo": "Tem ala (asa)?",
          "tipo": "bool",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "obstrucao_pct",
          "rotulo": "Obstrução da seção",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "%",
          "opcoes": [],
          "minimo": 0,
          "maximo": 100,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    },
    {
      "tipo": "ala",
      "rotulo": "Ala / boca (componente)",
      "categoria": "transversal",
      "geometria": "pontual",
      "atributos": [
        {
          "nome": "posicao",
          "rotulo": "Posição",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "montante",
            "jusante"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "material",
          "rotulo": "Material",
          "tipo": "enum",
          "obrigatorio": false,
          "unidade": null,
          "opcoes": [
            "concreto",
            "alvenaria",
            "pedra_argamassada"
          ],
          "minimo": null,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        },
        {
          "nome": "altura_cm",
          "rotulo": "Altura",
          "tipo": "numero",
          "obrigatorio": false,
          "unidade": "cm",
          "opcoes": [],
          "minimo": 0,
          "maximo": null,
          "ajuda": null,
          "depende_de": null,
          "depende_valor": null
        }
      ]
    }
  ]
};
