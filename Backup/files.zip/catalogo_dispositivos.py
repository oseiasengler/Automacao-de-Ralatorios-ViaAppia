"""
Catálogo de dispositivos de drenagem rodoviária — fonte única da verdade.

Define a taxonomia (DNIT) e o schema de atributos específicos de cada tipo.
Este módulo dirige:
  - a validação no backend (valida_atributos)
  - o formulário dinâmico no PWA (export_catalogo_js / catalogo.json)

Padrão de dados: núcleo comum (em models.py) + atributos específicos (JSONB),
validados aqui pelo tipo do dispositivo.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import json


class Categoria(str, Enum):
    SUPERFICIAL = "superficial"
    PROFUNDA = "profunda"
    TRANSVERSAL = "transversal"  # bueiros


class Geometria(str, Enum):
    LINEAR = "linear"      # tem extensão: km_ini -> km_fim, lat/lon entrada/saída
    PONTUAL = "pontual"    # ponto único: km, lat/lon


class TipoCampo(str, Enum):
    NUMERO = "numero"
    TEXTO = "texto"
    ENUM = "enum"
    BOOL = "bool"


@dataclass
class Campo:
    nome: str
    rotulo: str
    tipo: TipoCampo
    obrigatorio: bool = False
    unidade: str | None = None
    opcoes: list[str] = field(default_factory=list)
    minimo: float | None = None
    maximo: float | None = None
    ajuda: str | None = None
    # exibe o campo só quando outro campo tem certo valor (form condicional)
    depende_de: str | None = None
    depende_valor: str | None = None


@dataclass
class TipoDispositivo:
    tipo: str               # chave estável (snake_case)
    rotulo: str
    categoria: Categoria
    geometria: Geometria
    atributos: list[Campo] = field(default_factory=list)


# Materiais reutilizados
MAT_REVEST = ["concreto", "grama", "solo", "pead", "alvenaria", "pedra_argamassada"]
MAT_TUBO = ["concreto", "pead", "pvc", "metalico"]
SECOES = ["triangular", "trapezoidal", "retangular", "meia_cana"]


def _c(nome, rotulo, tipo, **kw) -> Campo:
    return Campo(nome=nome, rotulo=rotulo, tipo=tipo, **kw)


# ---------------------------------------------------------------------------
# CATÁLOGO
# ---------------------------------------------------------------------------
CATALOGO: list[TipoDispositivo] = [

    # ===================== SUPERFICIAL =====================
    TipoDispositivo(
        "canaleta", "Canaleta", Categoria.SUPERFICIAL, Geometria.LINEAR,
        [
            _c("secao", "Seção", TipoCampo.ENUM, obrigatorio=True, opcoes=SECOES),
            _c("material", "Material", TipoCampo.ENUM, obrigatorio=True, opcoes=MAT_REVEST),
            _c("largura_cm", "Largura", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("altura_cm", "Altura", TipoCampo.NUMERO, unidade="cm", minimo=0),
        ],
    ),
    TipoDispositivo(
        "sarjeta", "Sarjeta", Categoria.SUPERFICIAL, Geometria.LINEAR,
        [
            _c("posicao", "Posição", TipoCampo.ENUM, obrigatorio=True,
               opcoes=["corte", "aterro", "canteiro_central"]),
            _c("secao", "Seção", TipoCampo.ENUM, opcoes=SECOES),
            _c("material", "Material", TipoCampo.ENUM, opcoes=MAT_REVEST),
            _c("largura_cm", "Largura", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("altura_cm", "Altura", TipoCampo.NUMERO, unidade="cm", minimo=0),
        ],
    ),
    TipoDispositivo(
        "valeta_protecao", "Valeta de proteção", Categoria.SUPERFICIAL, Geometria.LINEAR,
        [
            _c("posicao", "Posição", TipoCampo.ENUM, obrigatorio=True,
               opcoes=["crista_corte", "pe_aterro", "banqueta"]),
            _c("secao", "Seção", TipoCampo.ENUM, opcoes=SECOES),
            _c("material", "Material", TipoCampo.ENUM, opcoes=MAT_REVEST),
            _c("largura_cm", "Largura", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("profundidade_cm", "Profundidade", TipoCampo.NUMERO, unidade="cm", minimo=0),
        ],
    ),
    TipoDispositivo(
        "meio_fio", "Meio-fio", Categoria.SUPERFICIAL, Geometria.LINEAR,
        [
            _c("tipo_mf", "Tipo", TipoCampo.ENUM, opcoes=["simples", "conjugado_sarjeta"]),
            _c("material", "Material", TipoCampo.ENUM, opcoes=["concreto", "pre_moldado"]),
            _c("altura_cm", "Altura", TipoCampo.NUMERO, unidade="cm", minimo=0),
        ],
    ),
    TipoDispositivo(
        "descida_dagua", "Descida d'água", Categoria.SUPERFICIAL, Geometria.LINEAR,
        [
            _c("tipo_descida", "Tipo", TipoCampo.ENUM, obrigatorio=True,
               opcoes=["rapida", "degraus"],
               ajuda="'degraus' = escada hidráulica"),
            _c("material", "Material", TipoCampo.ENUM, opcoes=["concreto", "pre_moldado", "alvenaria"]),
            _c("largura_cm", "Largura", TipoCampo.NUMERO, unidade="cm", minimo=0),
            # condicionais: só aparecem quando tipo_descida = degraus
            _c("n_degraus", "Nº de degraus", TipoCampo.NUMERO, minimo=1, obrigatorio=True,
               depende_de="tipo_descida", depende_valor="degraus"),
            _c("altura_espelho_cm", "Altura do espelho", TipoCampo.NUMERO, unidade="cm", minimo=0,
               depende_de="tipo_descida", depende_valor="degraus"),
            _c("tem_dissipador_saida", "Dissipador na saída?", TipoCampo.BOOL),
        ],
    ),
    TipoDispositivo(
        "dissipador_energia", "Dissipador de energia", Categoria.SUPERFICIAL, Geometria.PONTUAL,
        [
            _c("tipo_dissipador", "Tipo", TipoCampo.ENUM, obrigatorio=True,
               opcoes=["bacia", "enrocamento", "blocos", "escalonado"]),
            _c("comprimento_cm", "Comprimento", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("largura_cm", "Largura", TipoCampo.NUMERO, unidade="cm", minimo=0),
        ],
    ),
    TipoDispositivo(
        "caixa_coletora", "Caixa coletora / ligação", Categoria.SUPERFICIAL, Geometria.PONTUAL,
        [
            _c("funcao", "Função", TipoCampo.ENUM,
               opcoes=["coletora", "ligacao", "passagem"]),
            _c("largura_cm", "Largura", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("comprimento_cm", "Comprimento", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("profundidade_cm", "Profundidade", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("tem_grelha", "Tem grelha?", TipoCampo.BOOL),
        ],
    ),
    TipoDispositivo(
        "saida_dagua", "Saída/entrada d'água", Categoria.SUPERFICIAL, Geometria.PONTUAL,
        [
            _c("funcao", "Função", TipoCampo.ENUM, opcoes=["saida", "entrada"]),
            _c("material", "Material", TipoCampo.ENUM, opcoes=["concreto", "alvenaria"]),
            _c("largura_cm", "Largura", TipoCampo.NUMERO, unidade="cm", minimo=0),
        ],
    ),

    # ===================== PROFUNDA =====================
    TipoDispositivo(
        "dreno_longitudinal", "Dreno longitudinal", Categoria.PROFUNDA, Geometria.LINEAR,
        [
            _c("classe", "Classe", TipoCampo.ENUM, opcoes=["profundo", "raso_pavimento"]),
            _c("diametro_tubo_mm", "Ø tubo", TipoCampo.NUMERO, unidade="mm", minimo=0),
            _c("material_tubo", "Material do tubo", TipoCampo.ENUM, opcoes=MAT_TUBO),
            _c("profundidade_cm", "Profundidade", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("material_filtrante", "Material filtrante", TipoCampo.ENUM,
               opcoes=["brita", "areia", "geotextil", "misto"]),
        ],
    ),
    TipoDispositivo(
        "espinha_peixe", "Dreno espinha-de-peixe", Categoria.PROFUNDA, Geometria.LINEAR,
        [
            _c("diametro_tubo_mm", "Ø tubo", TipoCampo.NUMERO, unidade="mm", minimo=0),
            _c("profundidade_cm", "Profundidade", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("espacamento_m", "Espaçamento entre ramos", TipoCampo.NUMERO, unidade="m", minimo=0),
        ],
    ),
    TipoDispositivo(
        "dhp", "Dreno sub-horizontal (DHP)", Categoria.PROFUNDA, Geometria.PONTUAL,
        [
            _c("diametro_mm", "Ø", TipoCampo.NUMERO, unidade="mm", minimo=0),
            _c("comprimento_m", "Comprimento", TipoCampo.NUMERO, unidade="m", minimo=0),
            _c("inclinacao_graus", "Inclinação", TipoCampo.NUMERO, unidade="°"),
        ],
    ),
    TipoDispositivo(
        "colchao_drenante", "Colchão drenante", Categoria.PROFUNDA, Geometria.LINEAR,
        [
            _c("espessura_cm", "Espessura", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("material", "Material", TipoCampo.ENUM, opcoes=["brita", "areia", "misto"]),
        ],
    ),

    # ===================== TRANSVERSAL (bueiros) =====================
    TipoDispositivo(
        "bueiro_tubular", "Bueiro tubular (BSTC/BDTC/BTTC)", Categoria.TRANSVERSAL, Geometria.PONTUAL,
        [
            _c("n_linhas", "Nº de linhas", TipoCampo.ENUM, obrigatorio=True,
               opcoes=["1", "2", "3"], ajuda="1=simples, 2=duplo, 3=triplo"),
            _c("diametro_mm", "Ø", TipoCampo.NUMERO, obrigatorio=True, unidade="mm", minimo=0),
            _c("material", "Material", TipoCampo.ENUM, opcoes=["concreto", "metalico", "pead"]),
            _c("tem_ala", "Tem ala (asa)?", TipoCampo.BOOL),
            _c("tem_dissipador_saida", "Dissipador na saída?", TipoCampo.BOOL),
            _c("obstrucao_pct", "Obstrução da seção", TipoCampo.NUMERO, unidade="%", minimo=0, maximo=100),
        ],
    ),
    TipoDispositivo(
        "bueiro_celular", "Bueiro celular (BSCC/BDCC)", Categoria.TRANSVERSAL, Geometria.PONTUAL,
        [
            _c("n_celulas", "Nº de células", TipoCampo.ENUM, opcoes=["1", "2", "3"]),
            _c("largura_cm", "Largura", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("altura_cm", "Altura", TipoCampo.NUMERO, unidade="cm", minimo=0),
            _c("material", "Material", TipoCampo.ENUM, opcoes=["concreto"]),
            _c("tem_ala", "Tem ala (asa)?", TipoCampo.BOOL),
            _c("obstrucao_pct", "Obstrução da seção", TipoCampo.NUMERO, unidade="%", minimo=0, maximo=100),
        ],
    ),
    TipoDispositivo(
        "ala", "Ala / boca (componente)", Categoria.TRANSVERSAL, Geometria.PONTUAL,
        [
            _c("posicao", "Posição", TipoCampo.ENUM, opcoes=["montante", "jusante"]),
            _c("material", "Material", TipoCampo.ENUM, opcoes=["concreto", "alvenaria", "pedra_argamassada"]),
            _c("altura_cm", "Altura", TipoCampo.NUMERO, unidade="cm", minimo=0),
        ],
    ),
]

# Estado de conservação (núcleo comum a todos — padrão de fiscalização)
ESTADOS_CONSERVACAO = ["bom", "regular", "ruim", "critico"]

_POR_TIPO: dict[str, TipoDispositivo] = {d.tipo: d for d in CATALOGO}


# ---------------------------------------------------------------------------
# VALIDAÇÃO
# ---------------------------------------------------------------------------
def valida_atributos(tipo: str, atributos: dict[str, Any]) -> list[str]:
    """Retorna lista de erros (vazia = válido)."""
    disp = _POR_TIPO.get(tipo)
    if disp is None:
        return [f"tipo desconhecido: {tipo}"]

    erros: list[str] = []
    campos = {c.nome: c for c in disp.atributos}

    for c in disp.atributos:
        # pula validação de obrigatório se o campo é condicional e a condição não bate
        if c.depende_de:
            if str(atributos.get(c.depende_de)) != c.depende_valor:
                continue
        val = atributos.get(c.nome)
        if c.obrigatorio and (val is None or val == ""):
            erros.append(f"{c.nome}: obrigatório")
            continue
        if val is None or val == "":
            continue
        if c.tipo == TipoCampo.NUMERO:
            try:
                n = float(val)
            except (TypeError, ValueError):
                erros.append(f"{c.nome}: deve ser número")
                continue
            if c.minimo is not None and n < c.minimo:
                erros.append(f"{c.nome}: mínimo {c.minimo}")
            if c.maximo is not None and n > c.maximo:
                erros.append(f"{c.nome}: máximo {c.maximo}")
        elif c.tipo == TipoCampo.ENUM and val not in c.opcoes:
            erros.append(f"{c.nome}: valor inválido '{val}'")

    # avisa sobre atributos fora do schema (possível erro de cliente)
    for k in atributos:
        if k not in campos:
            erros.append(f"{k}: atributo não pertence ao tipo {tipo}")
    return erros


# ---------------------------------------------------------------------------
# EXPORT (alimenta o PWA)
# ---------------------------------------------------------------------------
def catalogo_dict() -> list[dict]:
    out = []
    for d in CATALOGO:
        item = asdict(d)
        item["categoria"] = d.categoria.value
        item["geometria"] = d.geometria.value
        for a in item["atributos"]:
            a["tipo"] = a["tipo"].value if hasattr(a["tipo"], "value") else a["tipo"]
        out.append(item)
    return out


def export_json(caminho: str = "catalogo.json") -> None:
    payload = {
        "estados_conservacao": ESTADOS_CONSERVACAO,
        "dispositivos": catalogo_dict(),
    }
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)


def export_js(caminho: str = "catalogo.js") -> None:
    """Gera o catálogo como módulo JS pro PWA embutir (offline, sem fetch)."""
    payload = {
        "estados_conservacao": ESTADOS_CONSERVACAO,
        "dispositivos": catalogo_dict(),
    }
    with open(caminho, "w", encoding="utf-8") as f:
        f.write("// GERADO POR catalogo_dispositivos.py — não editar à mão\n")
        f.write("window.CATALOGO = ")
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write(";\n")


if __name__ == "__main__":
    export_json("catalogo.json")
    export_js("../pwa/catalogo.js")
    print(f"{len(CATALOGO)} tipos exportados.")
