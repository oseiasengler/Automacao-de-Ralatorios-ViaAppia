"""
modulos/gerar_modelo_foto.py
──────────────────────────────────────────────────────────────────────────
Equivalente VBA: Art_022_EAF_Gerar_Mod_Ft_Exc_NC
Desenvolvedor: Ozeias Engler

Para cada XLS individual gerado pelo Módulo 01 (pasta Exportar/), produz
duas saídas (sequência macros Artesp 02): Kria e Resposta.

─── SAÍDA A – Planilha Kria de Abertura de Evento ──────────────────────
  Arquivo: yyyymmdd-hhmm - {nome_sem_extensao}.xlsx
  Pasta:   Arquivos/Arquivo Foto - Conserva/
  Modelo:  Modelo Abertura Evento Kria Conserva Rotina.
  Foto:    nc (N).jpg   ← foto da vistoria de campo

─── SAÍDA B – Relatório de Resposta à Artesp ───────────────────────────
  Arquivo: yyyymmdd-hhmmss - rodoviat - dd-mm-aaaa - tipo_nc.xlsx
  Pasta:   _Respostas/_Relatório EAF - NC/Pendentes/
  Modelo:  Modelo Resposta.
  Foto:    PDF (N).jpg  ← foto extraída do PDF
"""

import logging
from copy import copy
from datetime import datetime
from io import BytesIO
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.drawing.spreadsheet_drawing import TwoCellAnchor
from openpyxl.drawing.anchor import AnchorMarker
from openpyxl.utils import get_column_letter
from PIL import Image as PILImage

from utils.image_anchor import patch_add_image
from config import (
    M01_EXPORTAR,
    M02_FOTOS_NC,
    M02_FOTOS_PDF,
    M02_MODELO_KRIA,
    M02_SALVAR_FOTO,
    M02_MODELO_RESP,
    M02_PENDENTES,
    M02_FOTO_W, M02_FOTO_H,
    M02_FOTO_PDF_W, M02_FOTO_PDF_H,
    RODOVIAS,
)
from utils.helpers import (
    garantir_pasta,
    parse_data,
    data_br,
    data_yyyymmdd,
    km_mais_metros,
    km_virgula_metros,
    normalizar_rodovia_eaf,
    sanitizar_nome,
    timestamp_agora,
    timestamp_completo,
    caminho_dentro_limite_windows,
    xls_to_xlsx,
)

logger = logging.getLogger(__name__)

BLOCO      = 5    # linhas por NC no Kria
BLOCO_RESP = 28   # linhas por NC no Relatório de Resposta

# Índices de coluna do XLS individual (Módulo 01)
_C  = 3   # C – código fiscalização
_D  = 4   # D – data constatação
_E  = 5   # E – horário
_F  = 6   # F – rodovia
_H  = 8   # H – km inicial (int)
_I  = 9   # I – metros inicial
_J  = 10  # J – km final
_K  = 11  # K – metros final
_L  = 12  # L – sentido
_Q  = 17  # Q – tipo NC (Atividade)
_DR = 20  # T – Data Reparo (fallback; detectado dinamicamente)
_V  = 22  # V – nº da NC para foto

_NC_NOME_ARQ = {
    "Não Conformidade": "NC",
    "Advertência":      "ADV",
    "Notificação":      "NOT",
}

# ─────────────────────────────────────────────────────────────────────────────
# UTILITÁRIOS DE CAMINHO DE FOTO
# ─────────────────────────────────────────────────────────────────────────────

def path_foto_nc(pasta: Path, num: object) -> Path:
    """Foto de campo  →  nc (N).jpg   — usada no relatório Kria."""
    return pasta / f"nc ({num}).jpg"

def path_foto_pdf(pasta: Path, num: object) -> Path:
    """Foto extraída do PDF  →  PDF (N).jpg  — usada no relatório Resposta."""
    return pasta / f"PDF ({num}).jpg"

# ─────────────────────────────────────────────────────────────────────────────
# UTILITÁRIOS DE IMAGEM
# ─────────────────────────────────────────────────────────────────────────────

def _col_px(ws, col_letter: str) -> float:
    dim = ws.column_dimensions.get(col_letter)
    width = dim.width if (dim and dim.width) else 8.0
    return width * 7 + 5

def _row_px(ws, row: int) -> float:
    dim = ws.row_dimensions.get(row)
    height = dim.height if (dim and dim.height) else 15.0
    return height * 4 / 3

def _merged_range_px(ws, cell_addr: str):
    """Retorna (largura_px, altura_px) do merged range que contém cell_addr."""
    from openpyxl.utils import coordinate_to_tuple
    row, col = coordinate_to_tuple(cell_addr)
    for mc in ws.merged_cells.ranges:
        if mc.min_row <= row <= mc.max_row and mc.min_col <= col <= mc.max_col:
            w = sum(_col_px(ws, get_column_letter(c)) for c in range(mc.min_col, mc.max_col + 1))
            h = sum(_row_px(ws, r) for r in range(mc.min_row, mc.max_row + 1))
            return w, h
    col_letter = get_column_letter(col)
    return _col_px(ws, col_letter), _row_px(ws, row)

def _redimensionar_imagem_bytes(img_path: Path, largura: int, altura: int) -> bytes:
    with PILImage.open(str(img_path)) as im:
        im = im.convert("RGB")
        im = im.resize((int(largura), int(altura)), PILImage.LANCZOS)
        buf = BytesIO()
        im.save(buf, format="PNG")
        return buf.getvalue()

def _inserir_imagem(ws, cell_addr: str, img_path: Path, largura: int, altura: int):
    """Insere imagem ajustada ao merged range da célula âncora."""
    w, h = _merged_range_px(ws, cell_addr)
    data = _redimensionar_imagem_bytes(img_path, w, h)
    xl_img = XLImage(BytesIO(data))
    xl_img.width  = w
    xl_img.height = h
    ws.add_image(xl_img, cell_addr)

def _copiar_alturas_linhas(ws, src_start: int, num_linhas: int, dst_start: int):
    for offset in range(num_linhas):
        dim = ws.row_dimensions.get(src_start + offset)
        if dim is not None and dim.height is not None:
            ws.row_dimensions[dst_start + offset].height = dim.height

def _replicar_merged_cells(ws, row_ini_src: int, row_fim_src: int, row_ini_dst: int):
    desloc = row_ini_dst - row_ini_src
    ranges_a_replicar = []
    for mc in list(ws.merged_cells.ranges):
        if mc.min_row >= row_ini_src and mc.max_row <= row_fim_src:
            ranges_a_replicar.append((mc.min_row, mc.max_row, mc.min_col, mc.max_col))
    for min_r, max_r, min_c, max_c in ranges_a_replicar:
        try:
            ws.merge_cells(
                start_row=min_r + desloc, start_column=min_c,
                end_row=max_r + desloc,   end_column=max_c,
            )
        except Exception:
            pass

# ─────────────────────────────────────────────────────────────────────────────
# LEITURA DAS NCs
# ─────────────────────────────────────────────────────────────────────────────

def _detectar_col_data_reparo(ws, fallback: int = _DR) -> int:
    for col in range(1, ws.max_column + 1):
        val = ws.cell(row=4, column=col).value
        if val and "reparo" in str(val).lower():
            return col
    return fallback

def _cell(ws, row, col):
    return ws.cell(row=row, column=col).value

def _ler_ncs(ws, linha_inicio: int = 5) -> list:
    col_data_reparo = _detectar_col_data_reparo(ws, fallback=_DR)
    ultima = ws.max_row
    for r in range(ultima, linha_inicio - 1, -1):
        if ws.cell(row=r, column=_D).value:
            ultima = r
            break

    ncs = []
    for r in range(linha_inicio, ultima + 1):
        cod      = str(_cell(ws, r, _C) or "").strip()
        data_con = parse_data(_cell(ws, r, _D))
        hora     = str(_cell(ws, r, _E) or "").strip()
        rod_raw  = str(_cell(ws, r, _F) or "").strip()
        km_i_int = _cell(ws, r, _H)
        km_i_met = str(_cell(ws, r, _I) or "").strip()
        km_f_int = _cell(ws, r, _J)
        km_f_met = str(_cell(ws, r, _K) or "").strip()
        sentido  = str(_cell(ws, r, _L) or "").strip()
        tipo_nc  = str(_cell(ws, r, _Q) or "").strip()
        num_foto = _cell(ws, r, _V)
        data_rep = parse_data(_cell(ws, r, col_data_reparo))

        if not cod:
            continue

        rod_info = normalizar_rodovia_eaf(rod_raw, RODOVIAS)

        ncs.append({
            "codigo":      cod,
            "data_con":    data_con,
            "hora":        hora,
            "rod_raw":     rod_raw,
            "rod_codigo":  rod_info["codigo"],
            "rod_tag":     rod_info["tag"],
            "rod_n":       rod_info["n"],
            "km_i":        km_mais_metros(km_i_int, km_i_met),
            "km_i_virg":   km_virgula_metros(km_i_int, km_i_met),
            "km_f":        km_mais_metros(km_f_int, km_f_met),
            "km_f_virg":   km_virgula_metros(km_f_int, km_f_met),
            "sentido":     sentido,
            "tipo_nc":     tipo_nc,
            "num_foto":    int(num_foto) if num_foto else 0,
            "prazo_dias":  None,
            "data_reparo": data_rep,
        })

    return ncs

# ─────────────────────────────────────────────────────────────────────────────
# SAÍDA A – Planilha Kria  →  foto: nc (N).jpg
# ─────────────────────────────────────────────────────────────────────────────

def _gerar_kria(
    ncs: list, nome_base: str,
    modelo: Path, pasta_saida: Path,
    pasta_fotos_nc: Path,          # ← única fonte de foto para o Kria
    relatorio: str,
) -> "Path | None":
    """
    Preenche o modelo Kria com as NCs lidas e insere a foto de campo.

    Regra de foto (SAÍDA A):
        Usa EXCLUSIVAMENTE  nc (N).jpg  da pasta_fotos_nc.
        NÃO utiliza foto PDF aqui.

    Estrutura do bloco (5 linhas, âncora j=8 para a 1ª NC):
      j-2: B=seq,  C=tipo_nc
      j-1: C=âncora foto nc (275×210),  G=data_reparo
      j:   D=rodovia,  F=sentido,  G=tipo_nc
      j+1: D=km_i,  F=km_f,  H=codigo,  L=num_foto
      j+2: C="Vencimento",  D=data_reparo,  F=data_con,  H=relatorio,  L=prazo
    """
    if not modelo.exists():
        logger.error(f"Modelo Kria não encontrado: {modelo}")
        return None

    garantir_pasta(pasta_saida)
    nome_arq = f"{timestamp_agora()} - {nome_base}.xlsx"
    destino  = caminho_dentro_limite_windows(pasta_saida / nome_arq)
    garantir_pasta(destino.parent)

    wb = load_workbook(str(modelo))
    ws = wb.active
    patch_add_image(ws)

    n_ncs = len(ncs)
    if n_ncs == 0:
        logger.warning("Nenhuma NC para inserir na planilha Kria.")
        wb.save(str(destino))
        wb.close()
        return destino

    J_INICIO  = 8               # âncora da 1ª NC
    SRC_START = J_INICIO - 2   # linha 6 = início do bloco modelo

    # Expandir blocos extras para NC 2 em diante
    for extra in range(1, n_ncs):
        dst_start = SRC_START + extra * BLOCO
        ws.insert_rows(dst_start, BLOCO)
        for offset in range(BLOCO):
            for col in range(1, ws.max_column + 1):
                src_cell = ws.cell(row=SRC_START + offset, column=col)
                dst_cell = ws.cell(row=dst_start  + offset, column=col)
                dst_cell.value = src_cell.value
                if src_cell.has_style:
                    dst_cell.font          = copy(src_cell.font)
                    dst_cell.border        = copy(src_cell.border)
                    dst_cell.fill          = copy(src_cell.fill)
                    dst_cell.number_format = src_cell.number_format
                    dst_cell.alignment     = copy(src_cell.alignment)
        _copiar_alturas_linhas(ws, SRC_START, BLOCO, dst_start)
        _replicar_merged_cells(ws, SRC_START, SRC_START + BLOCO - 1, dst_start)

    # Preencher cada NC em ordem direta (NC[0] = topo)
    for idx, nc in enumerate(ncs):
        j  = J_INICIO + idx * BLOCO
        dr = nc["data_reparo"]
        dc = nc["data_con"]

        ws.cell(row=j - 2, column=2).value  = idx + 1
        ws.cell(row=j - 2, column=3).value  = nc["tipo_nc"]
        ws.cell(row=j - 1, column=7).value  = data_br(dr) if dr else ""
        ws.cell(row=j,     column=4).value  = nc["rod_codigo"]
        ws.cell(row=j,     column=6).value  = nc["sentido"]
        ws.cell(row=j,     column=7).value  = nc["tipo_nc"]
        ws.cell(row=j + 1, column=4).value  = nc["km_i"]
        ws.cell(row=j + 1, column=6).value  = nc["km_f"]
        ws.cell(row=j + 1, column=8).value  = nc["codigo"]
        ws.cell(row=j + 1, column=12).value = nc["num_foto"]
        ws.cell(row=j + 2, column=3).value  = "Vencimento"
        ws.cell(row=j + 2, column=4).value  = data_br(dr) if dr else ""
        ws.cell(row=j + 2, column=6).value  = data_br(dc) if dc else ""
        ws.cell(row=j + 2, column=8).value  = relatorio
        ws.cell(row=j + 2, column=12).value = nc["prazo_dias"]

        # ── Foto de campo: nc (N).jpg ─────────────────────────────────────────
        cell_foto = f"C{j - 1}"
        foto_path = path_foto_nc(pasta_fotos_nc, nc["num_foto"])
        if foto_path.exists():
            _inserir_imagem(ws, cell_foto, foto_path, M02_FOTO_W, M02_FOTO_H)
            logger.debug(f"  [Kria] Foto nc inserida: {foto_path.name} → {cell_foto}")
        else:
            logger.warning(f"  [Kria] Foto não encontrada: nc ({nc['num_foto']}).jpg")

    wb.save(str(destino))
    wb.close()
    logger.info(f"Saída A (Kria) salva: {destino.name}")
    return destino


# ─────────────────────────────────────────────────────────────────────────────
# SAÍDA B – Relatório de Resposta à Artesp  →  foto: PDF (N).jpg
# ─────────────────────────────────────────────────────────────────────────────

def _gerar_resposta(
    ncs: list, modelo: Path,
    pasta_saida: Path,
    pasta_fotos_pdf: Path,         # ← única fonte de foto para a Resposta
) -> "Path | None":
    """
    Preenche o modelo de resposta (28 linhas por NC) com cabeçalho e fotos.

    Regra de foto (SAÍDA B):
        Usa EXCLUSIVAMENTE  PDF (N).jpg  da pasta_fotos_pdf.
        NÃO utiliza foto nc aqui.

    Linha 1  (B1): cabeçalho longo da 1ª NC
    Linha 2  (B2): cabeçalho curto / âncora da foto PDF (480×202)
    NC 2 em diante: duplica bloco 1→28 ABAIXO do anterior e repete o padrão.
    """
    if not modelo.exists():
        logger.error(f"Modelo de resposta não encontrado: {modelo}")
        return None
    if not ncs:
        return None

    garantir_pasta(pasta_saida)

    nc1      = ncs[0]
    dr       = nc1["data_reparo"]
    dc       = nc1["data_con"]
    tipo_arq = _NC_NOME_ARQ.get(nc1["tipo_nc"], sanitizar_nome(nc1["tipo_nc"]))

    dr_str = dr.strftime("%d-%m-%Y") if dr else "00-00-0000"
    dc_str = dc.strftime("%d-%m-%Y") if dc else "00-00-0000"
    dr_br  = data_br(dr) if dr else ""
    dc_br  = data_br(dc) if dc else ""

    data_para_nome = dr or dc
    if not data_para_nome:
        for nc in ncs:
            data_para_nome = nc.get("data_reparo") or nc.get("data_con")
            if data_para_nome:
                break
    if not data_para_nome:
        data_para_nome = datetime.today()

    nome_arq = (
        f"{timestamp_completo()} - {nc1['rod_tag']} - "
        f"{dr_str} - {tipo_arq}.xlsx"
    )
    destino = caminho_dentro_limite_windows(pasta_saida / nome_arq)

    wb = load_workbook(str(modelo))
    ws = wb.active
    patch_add_image(ws)

    SRC_START = 1  # bloco modelo começa na linha 1

    def _cabecalho_longo(nc: dict, dr_: str, dc_: str) -> str:
        return (
            f"Relatório de Resposta - {nc['rod_tag']} - {nc['km_i']} - "
            f"{nc['sentido']} - Constatação: {dc_} - Reparo: {dr_} - "
            f"{nc['tipo_nc']}: {nc['codigo']}"
        )

    def _cabecalho_curto(nc: dict, dr_: str, dc_: str) -> str:
        return (
            f"{dc_} - {nc['rod_tag']} - {nc['km_i']} - "
            f"{nc['sentido']} - {dr_} - {nc['tipo_nc']} - {nc['codigo']}"
        )

    # ── NC 1: preenche o bloco existente no modelo ────────────────────────────
    ws.cell(row=1, column=2).value = _cabecalho_longo(nc1, dr_br, dc_br)
    ws.cell(row=2, column=2).value = _cabecalho_curto(nc1, dr_str, dc_str)

    # Foto PDF: PDF (N).jpg
    foto1 = path_foto_pdf(pasta_fotos_pdf, nc1["num_foto"])
    if foto1.exists():
        _inserir_imagem(ws, "B2", foto1, M02_FOTO_PDF_W, M02_FOTO_PDF_H)
        logger.debug(f"  [Resposta] Foto PDF inserida: {foto1.name} → B2")
    else:
        logger.warning(f"  [Resposta] Foto PDF não encontrada: PDF ({nc1['num_foto']}).jpg")

    # ── NCs 2..N: duplicar bloco ABAIXO do anterior ───────────────────────────
    linha = 1  # ponteiro para o início do bloco atual

    for nc in ncs[1:]:
        dst_start = linha + BLOCO_RESP  # sempre abaixo → ordem direta

        ws.insert_rows(dst_start, BLOCO_RESP)

        for offset in range(BLOCO_RESP):
            for col in range(1, ws.max_column + 1):
                src_cell = ws.cell(row=SRC_START + offset, column=col)
                dst_cell = ws.cell(row=dst_start  + offset, column=col)
                dst_cell.value = src_cell.value
                if src_cell.has_style:
                    dst_cell.font          = copy(src_cell.font)
                    dst_cell.border        = copy(src_cell.border)
                    dst_cell.fill          = copy(src_cell.fill)
                    dst_cell.number_format = src_cell.number_format
                    dst_cell.alignment     = copy(src_cell.alignment)

        _copiar_alturas_linhas(ws, SRC_START, BLOCO_RESP, dst_start)
        _replicar_merged_cells(ws, SRC_START, SRC_START + BLOCO_RESP - 1, dst_start)

        nc_dr    = nc["data_reparo"]
        nc_dc    = nc["data_con"]
        nc_dr_br = data_br(nc_dr) if nc_dr else ""
        nc_dc_br = data_br(nc_dc) if nc_dc else ""
        nc_dr_s  = nc_dr.strftime("%d-%m-%Y") if nc_dr else "00-00-0000"
        nc_dc_s  = nc_dc.strftime("%d-%m-%Y") if nc_dc else "00-00-0000"

        # 1. Cabeçalhos PRIMEIRO
        ws.cell(row=dst_start,     column=2).value = _cabecalho_longo(nc, nc_dr_br, nc_dc_br)
        ws.cell(row=dst_start + 1, column=2).value = _cabecalho_curto(nc, nc_dr_s,  nc_dc_s)

        # 2. Foto PDF: PDF (N).jpg — DEPOIS dos cabeçalhos
        foto_v    = path_foto_pdf(pasta_fotos_pdf, nc["num_foto"])
        cell_foto = f"B{dst_start + 1}"
        if foto_v.exists():
            _inserir_imagem(ws, cell_foto, foto_v, M02_FOTO_PDF_W, M02_FOTO_PDF_H)
            logger.debug(f"  [Resposta] Foto PDF inserida: {foto_v.name} → {cell_foto}")
        else:
            logger.warning(f"  [Resposta] Foto PDF não encontrada: PDF ({nc['num_foto']}).jpg")

        linha = dst_start  # avança ponteiro

    wb.save(str(destino))
    wb.close()
    logger.info(f"Saída B (Resposta) salva: {destino.name}")
    return destino


# ─────────────────────────────────────────────────────────────────────────────
# FUNÇÃO PRINCIPAL
# ─────────────────────────────────────────────────────────────────────────────

def executar(
    pasta_xls: "Path | None" = None,
    modelo_kria: "Path | None" = None,
    pasta_saida_kria: "Path | None" = None,
    modelo_resposta: "Path | None" = None,
    pasta_saida_resp: "Path | None" = None,
    pasta_fotos_nc: "Path | None" = None,
    pasta_fotos_pdf: "Path | None" = None,
    callback_progresso=None,
) -> dict:
    """
    Processa todos os XLS da pasta de entrada e gera:
      - Kria    (Saída A) com fotos  nc (N).jpg
      - Resposta (Saída B) com fotos  PDF (N).jpg

    Retorna dict: { 'kria': [...], 'resposta': [...], 'erros': [...] }
    """
    pasta_xls        = pasta_xls        or M01_EXPORTAR
    modelo_kria      = modelo_kria      or M02_MODELO_KRIA
    pasta_saida_kria = pasta_saida_kria or M02_SALVAR_FOTO
    modelo_resposta  = modelo_resposta  or M02_MODELO_RESP
    pasta_saida_resp = pasta_saida_resp or M02_PENDENTES
    pasta_fotos_nc   = pasta_fotos_nc   or M02_FOTOS_NC    # nc (N).jpg
    pasta_fotos_pdf  = pasta_fotos_pdf  or M02_FOTOS_PDF   # PDF (N).jpg

    garantir_pasta(pasta_saida_kria)
    garantir_pasta(pasta_saida_resp)

    arquivos = sorted([
        f for f in pasta_xls.glob("*.xls*")
        if not f.name.startswith("~") and not f.name.startswith("_")
    ])

    if not arquivos:
        logger.warning(f"Nenhum XLS encontrado em: {pasta_xls}")
        return {"kria": [], "resposta": [], "erros": []}

    logger.info(f"Módulo 02: {len(arquivos)} arquivo(s) para processar.")
    resultados = {"kria": [], "resposta": [], "erros": []}

    for idx, arq in enumerate(arquivos):
        if callback_progresso:
            callback_progresso(idx + 1, len(arquivos), f"Processando: {arq.name[:60]}")

        logger.info(f"\n── Processando [{idx+1}/{len(arquivos)}]: {arq.name}")

        try:
            if arq.suffix.lower() == ".xls":
                path_para_abrir = xls_to_xlsx(arq, dest=None)
                remover_depois  = True
            else:
                path_para_abrir = arq
                remover_depois  = False

            wb = load_workbook(str(path_para_abrir), data_only=True)
            try:
                ws  = wb.active
                ncs = _ler_ncs(ws)
            finally:
                wb.close()
                if remover_depois and path_para_abrir.exists():
                    path_para_abrir.unlink(missing_ok=True)

            if not ncs:
                logger.warning(f"  Nenhuma NC encontrada em {arq.name}, pulando.")
                continue

            logger.info(f"  {len(ncs)} NC(s) lida(s).")

            nome_base = arq.stem
            relatorio = nome_base[:8]

            # ── Saída A: Kria  →  nc (N).jpg ─────────────────────────────────
            arq_kria = _gerar_kria(
                ncs, nome_base,
                modelo_kria, pasta_saida_kria,
                pasta_fotos_nc,   # ← foto de campo
                relatorio,
            )
            if arq_kria:
                resultados["kria"].append(arq_kria)

            # ── Saída B: Resposta  →  PDF (N).jpg ────────────────────────────
            arq_resp = _gerar_resposta(
                ncs,
                modelo_resposta, pasta_saida_resp,
                pasta_fotos_pdf,  # ← foto do PDF
            )
            if arq_resp:
                resultados["resposta"].append(arq_resp)

        except Exception as e:
            logger.error(f"  ERRO em {arq.name}: {e}", exc_info=True)
            resultados["erros"].append(arq.name)

    total_k = len(resultados["kria"])
    total_r = len(resultados["resposta"])
    total_e = len(resultados["erros"])
    logger.info(
        f"\nMódulo 02 concluído: "
        f"{total_k} Kria, {total_r} resposta(s), {total_e} erro(s)."
    )
    if callback_progresso:
        callback_progresso(len(arquivos), len(arquivos), "Módulo 02 concluído.")

    return resultados
