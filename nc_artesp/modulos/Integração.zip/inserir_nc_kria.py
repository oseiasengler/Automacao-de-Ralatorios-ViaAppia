"""
modulos/inserir_nc_kria.py
────────────────────────────────────────────────────────────────────────────
Desenvolvedor: Ozeias Engler
Equivalente VBA:
  • Art_03_Inserir_NC_Rot_Salva_apo  → modo='conservacao'
  • Kria2_Inserir_NC_MA_Salvar_Img   → modo='meio_ambiente'

Para cada arquivo XLSX da pasta de entrada (formulário de foto com
layout de 5 linhas por NC):

  FASE 1 – Exportar imagem do bloco de células
  ─────────────────────────────────────────────
  Para cada NC (bloco de 5 linhas, âncora y):
    • Captura o range C(y-3):F(y+1) como JPG via xlwings (COM) ou fallback Pillow
    • Nome do JPG: yyyymmdd - hhmmss - n_Roti-NNNNNN-RODOVIA km,metro SENTIDO.jpg

    [só módulo 03] Copia também pdf (N).jpg da pasta PDF para pasta Conservação

  FASE 2 – Montar planilha Kcor-Kria
  ────────────────────────────────────
  Abre o modelo _Planilha Modelo Kcor-Kria.XLSX e preenche uma linha por NC.
  Template: linha 1 = cabeçalhos A–Y, linha 2+ = dados. Preenchimento inicia
  na coluna A (sem offset) para compatibilidade com importação no sistema Kcor.

  Col | Conservação (mod 03)          | Meio Ambiente (mod 07)
  ────┼───────────────────────────────┼──────────────────────────────────────
   A  | sequencial (x)                | sequencial (x)
   B  | "Artesp"                      | "Artesp"
   C  | "2"                           | "2"
   D  | classifica (do mapa serviços) | "Conservação Rotina"
   E  | serv (tipo NC mapeado)        | "Reclassificar"
   F  | rodovia (tag)                 | rodovia (tag)
   G  | kminicial_t                   | kminicial_t
   H  | kmfinal_t                     | kmfinal_t
   I  | Sentido                       | Sentido
   J  | (vazio)                       | (vazio)
   K  | "Conservação"                 | "Conservação"
   L  | executor                      | (vazio → offset 2 a partir de K)
   M  | data (mm/dd/yyyy)             | data (mm/dd/yyyy)
   N  | (vazio)                       | (vazio)
   O  | data (mm/dd/yyyy) [DtInicio]  | data (mm/dd/yyyy)
   P  | embasamento (DtFim)           | (vazio → offset 6 a partir de O)
   S  | Prazo                         | Prazo
   T  | Obs Gestor (rel + código)     | Obs Gestor (rel + código)
   U  | Observações (texto+compl+emb) | Observações (texto+compl+emb)
   V  | Diretório                     | Diretório
   W  | arquivo.jpg                   | arquivo.jpg

  FASE 3 – Finalização
  ─────────────────────
  • Salva Kcor-Kria em pasta de saída com timestamp
  • Renomeia o arquivo de entrada para "_Processado - {nome}.xlsx"

Layout do formulário de entrada (âncora y=9 = linha do km, equivale a j+1 do M02 com j=8):
  y-3 (linha 6)  → B=número NC (col 2)  — início do range de captura C(y-3):F(y+1)
  y-2 (linha 7)  → G=embasamento/data_reparo (col 7)
  y-1 (linha 8)  → D=rodovia (col 4), F=sentido (col 6), G=texto/tipo NC (col 7)
  y   (linha 9)  → D=km inicial (col 4), F=km final (col 6), H=código (col 8), L=foto/complemento (col 12)
  y+1 (linha 10) → C="Vencimento", D=data reparo (col 4), F=data constatação (col 6), H=relatório (col 8), L=prazo dias (col 12)
"""

import logging
from pathlib import Path
from datetime import datetime
import re

from openpyxl import load_workbook

from config import (
    M03_ENTRADA, M03_IMAGENS, M03_MODELO_KCOR, M03_SAIDA,
    M03_LINHA_INICIO, M03_BLOCO,
    M07_ENTRADA, M07_IMAGENS, M07_SAIDA,
    M02_FOTOS_NC, M02_FOTOS_PDF,
    SERVICO_NC, RODOVIAS,
)
from utils.helpers import (
    garantir_pasta,
    caminho_dentro_limite_windows,
    copiar_arquivo,
    renomear_arquivo,
    parse_data,
    encontrar_foto_por_codigo_ou_numero,
    path_foto_nc,
    path_foto_pdf,
    sanitizar_nome,
    timestamp_agora,
    timestamp_completo,
    km_formato_arquivo,
    formatar_numero,
)
from utils.onedrive_local import processar_com_copia_local
from utils.captura_celulas import (
    exportar_range_como_imagem,
    TAMANHO_CONSERVACAO,
    TAMANHO_MA,
)

logger = logging.getLogger(__name__)

# ─── Colunas do formulário de entrada (1-based) ───────────────────────────────
_COL_B  = 2   # número NC / âncora para seleção
_COL_D  = 4   # rodovia (y-1), km inicial (y)
_COL_F  = 6   # sentido (y-1), km final (y), data (y+1)
_COL_G  = 7   # embasamento (y-2), texto/descrição (y-1)
_COL_H  = 8   # código (y), relatório (y+1)
_COL_L  = 12  # complemento/nº foto (y), prazo dias (y+2)
_COL_C  = 3   # usada apenas para detectar última linha com dado

# ─── Colunas da planilha Kcor-Kria de saída (1-based) ─────────────────────────
# Template inicia em A; nenhuma coluna deve ser pulada para importação Kcor
_K_A  = 1    # NumItem (sequencial)
_K_B  = 2    # Origem ("Artesp")
_K_C  = 3    # Motivo ("2")
_K_D  = 4    # Classificação
_K_E  = 5    # Tipo NC
_K_F  = 6    # Rodovia
_K_G  = 7    # KMi
_K_H  = 8    # KMf
_K_I  = 9    # Sentido
_K_J  = 10   # Local (vazio)
_K_K  = 11   # Gestor ("Conservação")
_K_L  = 12   # executor (mod 03 only)
_K_M  = 13   # data solicitação (data constatação)
_K_N  = 14   # data suspensão
_K_O  = 15   # DtInicio_Prog
_K_P  = 16   # DtFim_Prog / embasamento (data reparo)
_K_Q  = 17   # DtInicio_Exec (data início execução)
_K_R  = 18   # DtFim_Exec (data fim execução)
_K_S  = 19   # prazo
_K_T  = 20   # obs gestor
_K_U  = 21   # observações
_K_V  = 22   # diretório
_K_W  = 23   # arquivos
_K_X  = 24   # Indicador (vazio)
_K_Y  = 25   # Unidade (preenchido pelo M05)


def _cell(ws, row: int, col: int):
    v = ws.cell(row=row, column=col).value
    return v if v is not None else ""


def _copiar_estilo_linha(ws, row_origem: int, row_destino: int, col_fim: int = 25):
    """Copia bordas e estilos da linha modelo para preservar formatação ao gravar."""
    for col in range(1, col_fim + 1):
        src = ws.cell(row=row_origem, column=col)
        dst = ws.cell(row=row_destino, column=col)
        if src.has_style:
            dst.font = src.font.copy()
            dst.border = src.border.copy()
            dst.fill = src.fill.copy()
            dst.number_format = src.number_format
            dst.alignment = src.alignment.copy()


def _str(v) -> str:
    return str(v).strip() if v is not None else ""


def _normalizar_rodovia_formulario(rod_raw: str) -> tuple[str, str, int]:
    """
    Recebe valor da col D(y-1) do formulário — já no formato SP-075, SPI-102/300 etc.
    Retorna (tag, codigo, n).
    """
    rod = rod_raw.strip()
    mapa = {
        "SP-075":     ("SP075",     "SP075",     1),
        "SP-127":     ("SP127",     "SP127",     2),
        "SP-280":     ("SP280",     "SP280",     3),
        "SP-300":     ("SP300",     "SP300",     4),
        "SPI-102/300":("SPI102_300","SPI102/300",5),
        "CP-127_147": ("CP-127_147","FORA",      6),
        "CP-127_308": ("CP-127_308","FORA",      7),
    }
    if rod in mapa:
        return mapa[rod]
    # fallback: limpeza básica
    tag = sanitizar_nome(rod).replace("-", "").replace("/", "_")
    return (tag, rod, 0)


def _data_nome_yyyymmdd(data_str: str, nome_origem: str = "") -> str:
    """
    Resolve a data usada no nome do JPG.
    Prioridade:
      1) data_str válida (vinda da planilha)
      2) data no nome do arquivo de origem (preferindo a 2ª ocorrência yyyyMMdd)
      3) data atual
    """
    dt = parse_data(data_str)
    if dt:
        return dt.strftime("%Y%m%d")

    datas_nome = re.findall(r"\b(20\d{6})\b", nome_origem or "")
    if datas_nome:
        return datas_nome[1] if len(datas_nome) >= 2 else datas_nome[0]

    return datetime.now().strftime("%Y%m%d")


def _nome_arquivo_jpg(data_str: str, n: int, numero: str,
                      rodoviat: str, kminicial: str, sentido: str,
                      nome_origem: str = "") -> str:
    """
    Monta o nome do JPG exportado.
    Formato VBA: yyyymmdd - hhmmss - n_Roti-NNNNNN-RODOVIA km,metro SENTIDO.jpg
    """
    yyyymmdd = _data_nome_yyyymmdd(data_str, nome_origem=nome_origem)
    return sanitizar_nome(
        f"{yyyymmdd} - {timestamp_completo()} - "
        f"{n}_Roti-{numero}-{rodoviat} {kminicial} {sentido}.jpg"
    )


def _obs_gestor(relatorio: str, codigo: str) -> str:
    return f"--> Relatório EAF Conservação Rotina nº: {relatorio}\n\n--> Código NC: {codigo}"


def _observacoes(texto: str, complemento: str, embasamento: str) -> str:
    if complemento:
        return (
            f"{texto}\n\n"
            f"- Complemento ----> {complemento}\n\n"
            f"- Embasamento ----> {embasamento}"
        )
    return f"{texto}\n\n- Data Superação Artesp ----> {embasamento}"


# ─────────────────────────────────────────────────────────────────────────────
# PROCESSAMENTO DE UM ÚNICO ARQUIVO
# ─────────────────────────────────────────────────────────────────────────────

def _processar_arquivo(arq_path: Path,
                        modo: str,
                        pasta_imagens: Path,
                        pasta_fotos_pdf: Path | None,
                        pasta_fotos_nc: Path | None,
                        modelo_kcor: Path,
                        pasta_saida: Path,
                        forcar_fallback: bool = False) -> Path | None:
    """
    Processa um único arquivo XLSX de formulário de foto.
    Retorna o Path do Kcor-Kria gerado, ou None em caso de erro.
    """
    eh_conservacao = (modo == "conservacao")
    tamanho_img = TAMANHO_CONSERVACAO if eh_conservacao else TAMANHO_MA
    largura, altura = tamanho_img

    logger.info(f"Processando [{modo}]: {arq_path.name}")

    # ── Abrir e ler o formulário ──────────────────────────────────────────────
    wb_form = load_workbook(str(arq_path), data_only=True)
    ws      = wb_form.active

    # Última linha com dado na col C
    ultima = ws.max_row
    for r in range(ultima, M03_LINHA_INICIO - 1, -1):
        if ws.cell(row=r, column=_COL_C).value is not None:
            ultima = r
            break

    registros = []
    y = M03_LINHA_INICIO  # âncora da 1ª NC (linha 9)

    while y <= ultima + (M03_BLOCO - 2):  # tolerância de y+1
        # Verificar se há dado na linha âncora
        if not _str(_cell(ws, y, _COL_D)) and not _str(_cell(ws, y, _COL_H)):
            break

        # ── Ler campos ────────────────────────────────────────────────────────
        # Layout Kria (âncora j=8 em M02; y=9=j+1 aqui):
        #   y-3 (j-2=6): B=nº NC                      → numero
        #   y-2 (j-1=7): G=data_reparo (embasamento)  → embasamento
        #   y-1 (j=8):   D=rodovia, F=sentido, G=tipo NC (texto)
        #   y   (j+1=9): D=km_i, F=km_f, H=codigo, L=foto/complemento
        #   y+1 (j+2=10): C="Vencimento", D=data_reparo, F=data_con, H=relatório, L=prazo
        relatorio   = _str(_cell(ws, y + 1, _COL_H))   # H(y+1) = H10 — relatório
        codigo      = _str(_cell(ws, y,     _COL_H))   # H(y)   = H9  — código NC
        complemento = _str(_cell(ws, y,     _COL_L))   # L(y)   = L9  — complemento/foto
        embasamento = _str(_cell(ws, y - 2, _COL_G))   # G(y-2) = G7  — data reparo
        rod_raw     = _str(_cell(ws, y - 1, _COL_D))   # D(y-1) = D8  — rodovia
        texto       = _str(_cell(ws, y - 1, _COL_G))   # G(y-1) = G8  — tipo NC / descrição
        sentido     = _str(_cell(ws, y - 1, _COL_F))   # F(y-1) = F8  — sentido
        kminicial_t = _str(_cell(ws, y,     _COL_D))   # D(y)   = D9  — km inicial
        kmfinal_t   = _str(_cell(ws, y,     _COL_F))   # F(y)   = F9  — km final
        data_raw    = _str(_cell(ws, y + 1, _COL_F))   # F(y+1) = F10 — data constatação
        prazo       = _cell(ws, y + 1, _COL_D) or _cell(ws, y + 1, _COL_L)  # D/L(y+1)=D10/L10
        numero_raw  = _cell(ws, y - 3, _COL_B)         # B(y-3) = B6  — nº sequencial

        # [Conservação] número da foto (col L linha y é o foto_id no mod 03 original
        # — porém no mod 03 a foto vem de "Range L & y" que é o complemento.
        # Revisando: foto(i) = Range("L" & y).Value — sim, complemento e foto
        # compartilham a col L linha y. No contexto dos dados, complemento é
        # texto descritivo e foto é um número. Usamos o mesmo campo; se for
        # numérico, é o nº da foto; senão, é texto de complemento.
        foto_id = None
        try:
            foto_id = int(float(str(complemento))) if complemento else None
            complemento = ""  # se era número, era o foto_id, não texto
        except (ValueError, TypeError):
            pass  # é realmente texto de complemento

        # Normalizar rodovia
        rod_tag, rod_cod, n = _normalizar_rodovia_formulario(rod_raw)

        # KM inicial formatado para nome de arquivo
        kminicial_arq = km_formato_arquivo(kminicial_t)

        # Número NC formatado
        numero = formatar_numero(numero_raw or 1, 6)

        # Data
        dt = parse_data(data_raw)
        data_str_raw = data_raw

        # ── Mapeamento serviço → tipo NC (só Conservação) ─────────────────────
        if eh_conservacao:
            descricao = texto  # col G y-1 é a descrição do serviço
            nc_info   = SERVICO_NC.get(descricao, None)
            if nc_info:
                serv_nc, classifica, executor = nc_info
            else:
                serv_nc    = ""
                classifica = "Conservação Rotina"
                executor   = "Soluciona - Conserva"
        else:
            serv_nc    = "Reclassificar"
            classifica = "Conservação Rotina"
            executor   = ""

        registros.append({
            "y":           y,
            "relatorio":   relatorio,
            "codigo":      codigo,
            "complemento": complemento,
            "embasamento": embasamento,
            "rod_raw":     rod_raw,
            "rod_tag":     rod_tag,
            "rod_cod":     rod_cod,
            "n":           n,
            "texto":       texto,
            "sentido":     sentido,
            "kminicial_t": kminicial_t,
            "kmfinal_t":   kmfinal_t,
            "kminicial_arq": kminicial_arq,
            "data_raw":    data_str_raw,
            "dt":          dt,
            "prazo":       prazo,
            "numero":      numero,
            "foto_id":     foto_id,
            "serv_nc":     serv_nc,
            "classifica":  classifica,
            "executor":    executor,
        })
        y += M03_BLOCO

    wb_form.close()

    if not registros:
        logger.warning(f"  Nenhum registro encontrado em {arq_path.name}")
        return None

    logger.info(f"  {len(registros)} NC(s) lida(s).")

    # ── FASE 1: Exportar imagens ──────────────────────────────────────────────
    garantir_pasta(pasta_imagens)
    nomes_arquivo = []

    for reg in registros:
        y_anc = reg["y"]

        # Range: C(y-3):F(y+1)  → col C=3, F=6
        row_ini = y_anc - 3
        col_ini = 3   # C
        row_fim = y_anc + 1
        col_fim = 6   # F

        nome_jpg = _nome_arquivo_jpg(
            reg["data_raw"], reg["n"], reg["numero"],
            reg["rod_tag"], reg["kminicial_arq"], reg["sentido"],
            nome_origem=arq_path.name,
        )
        destino_jpg = pasta_imagens / nome_jpg

        # Conservação com foto_id: só usar foto real do PDF/NC, nunca print da planilha.
        # Busca por código (ex.: PDF (896643).jpg) e por número (ex.: PDF (1).jpg).
        foto_real_existe = False
        foto_pdf = foto_nc = None
        if eh_conservacao and pasta_fotos_pdf and (reg.get("codigo") or reg.get("foto_id") is not None):
            codigo = reg.get("codigo")
            foto_id = reg.get("foto_id")
            foto_pdf = encontrar_foto_por_codigo_ou_numero(
                pasta_fotos_pdf, "PDF", codigo=codigo, numero=foto_id
            )
            if pasta_fotos_nc:
                foto_nc = encontrar_foto_por_codigo_ou_numero(
                    pasta_fotos_nc, "nc", codigo=codigo, numero=foto_id
                )
            foto_real_existe = (foto_pdf is not None) or (foto_nc is not None)

        if eh_conservacao:
            # M03 (Conservação): nunca gerar print da planilha.
            # Usa somente foto real (PDF (N).jpg / nc (N).jpg) quando existir (por código ou foto_id).
            if pasta_fotos_pdf and foto_real_existe:
                origem_foto = None
                if foto_pdf and foto_pdf.exists():
                    origem_foto = foto_pdf
                elif foto_nc and foto_nc.exists():
                    origem_foto = foto_nc
                if origem_foto:
                    copiar_arquivo(origem_foto, destino_jpg, sobrescrever=True)
                    logger.debug(f"  Foto real usada: {origem_foto.name} → {nome_jpg}")
                else:
                    nome_jpg = ""
            else:
                nome_jpg = ""
                logger.debug(
                    f"  NC y={y_anc}: foto real indisponível (foto_id={reg['foto_id']}), "
                    "não exportando print da planilha."
                )
        else:
            ok = exportar_range_como_imagem(
                wb_path      = arq_path,
                sheet_index  = 0,
                row_ini      = row_ini,
                col_ini      = col_ini,
                row_fim      = row_fim,
                col_fim      = col_fim,
                destino      = destino_jpg,
                largura      = largura,
                altura       = altura,
                forcar_fallback = forcar_fallback,
            )
            if ok:
                logger.debug(f"  JPG gerado: {nome_jpg}")
            else:
                logger.warning(f"  Falha ao exportar JPG para NC y={y_anc}")
                nome_jpg = ""

        nomes_arquivo.append(nome_jpg)

    # ── FASE 2: Montar planilha Kcor-Kria ────────────────────────────────────
    if not modelo_kcor.exists():
        logger.error(f"Modelo Kcor-Kria não encontrado: {modelo_kcor}")
        return None

    garantir_pasta(pasta_saida)

    wb_kcor = load_workbook(str(modelo_kcor))
    ws_out  = wb_kcor.active

    for seq, (reg, nome_arq) in enumerate(zip(registros, nomes_arquivo), start=1):
        r = seq + 1  # linha de saída (linha 2 em diante)

        dt     = reg["dt"]
        emb    = parse_data(reg["embasamento"])
        dt_str = dt.strftime("%m/%d/%Y")  if dt  else ""
        emb_str= emb.strftime("%m/%d/%Y") if emb else ""

        ws_out.cell(row=r, column=_K_A).value = seq
        ws_out.cell(row=r, column=_K_B).value = "Artesp"
        ws_out.cell(row=r, column=_K_C).value = "2"
        ws_out.cell(row=r, column=_K_D).value = reg["classifica"]
        ws_out.cell(row=r, column=_K_E).value = reg["serv_nc"]
        ws_out.cell(row=r, column=_K_F).value = reg["rod_tag"]
        ws_out.cell(row=r, column=_K_G).value = reg["kminicial_t"]
        ws_out.cell(row=r, column=_K_H).value = reg["kmfinal_t"]
        ws_out.cell(row=r, column=_K_I).value = reg["sentido"]
        ws_out.cell(row=r, column=_K_J).value = ""  # Local (vazio)
        ws_out.cell(row=r, column=_K_K).value = "Conservação"

        if eh_conservacao:
            ws_out.cell(row=r, column=_K_L).value = reg["executor"]
            ws_out.cell(row=r, column=_K_M).value = dt_str   # Data Solicitação (data constatação)
            ws_out.cell(row=r, column=_K_N).value = ""       # Data Suspensão (vazio)
            ws_out.cell(row=r, column=_K_O).value = dt_str   # DtInicio_Prog
            ws_out.cell(row=r, column=_K_P).value = emb_str  # DtFim_Prog (data reparo)
            ws_out.cell(row=r, column=_K_Q).value = emb_str  # DtInicio_Exec (data execução)
            ws_out.cell(row=r, column=_K_R).value = emb_str  # DtFim_Exec (data execução)
        else:
            ws_out.cell(row=r, column=_K_M).value = dt_str
            ws_out.cell(row=r, column=_K_N).value = ""       # Data Suspensão
            ws_out.cell(row=r, column=_K_O).value = dt_str
            ws_out.cell(row=r, column=_K_Q).value = emb_str
            ws_out.cell(row=r, column=_K_R).value = emb_str

        ws_out.cell(row=r, column=_K_S).value = reg["prazo"]
        ws_out.cell(row=r, column=_K_T).value = _obs_gestor(reg["relatorio"], reg["codigo"])
        ws_out.cell(row=r, column=_K_U).value = _observacoes(
            reg["texto"], reg["complemento"], reg["embasamento"]
        )
        ws_out.cell(row=r, column=_K_V).value = str(pasta_imagens)

        # Col W: manter apenas o nome formatado da imagem final
        ws_out.cell(row=r, column=_K_W).value = nome_arq
        ws_out.cell(row=r, column=_K_X).value = ""  # Indicador (vazio; col Y pelo M05)

        # Preservar bordas e estilos da linha modelo (evitar apagar formatação ao gravar)
        _copiar_estilo_linha(ws_out, row_origem=2, row_destino=r, col_fim=25)

    # Salvar Kcor-Kria (dentro do limite de 259 caracteres para o Excel abrir)
    nome_saida = f"{timestamp_agora()} - {arq_path.name}"
    destino_kcor = caminho_dentro_limite_windows(pasta_saida / nome_saida)
    garantir_pasta(destino_kcor.parent)
    wb_kcor.save(str(destino_kcor))
    wb_kcor.close()
    logger.info(f"  Kcor-Kria salvo: {destino_kcor.name}")

    # ── FASE 3: Renomear arquivo de entrada para "_Processado - nome" ─────────
    novo_nome = arq_path.parent / f"_Processado - {arq_path.name}"
    renomear_arquivo(arq_path, novo_nome)

    return destino_kcor


# ─────────────────────────────────────────────────────────────────────────────
# FUNÇÕES PÚBLICAS
# ─────────────────────────────────────────────────────────────────────────────

def executar_conservacao(pasta_entrada: Path | None = None,
                          pasta_imagens: Path | None = None,
                          modelo_kcor:   Path | None = None,
                          pasta_saida:   Path | None = None,
                          pasta_fotos_pdf: Path | None = None,
                          pasta_fotos_nc: Path | None = None,
                          forcar_fallback: bool = False,
                          callback_progresso=None) -> list[Path]:
    """
    Módulo 03 (+ 031): Conservação Rotina.
    Processa todos os .xlsx da pasta de entrada no modo 'conservacao'.
    """
    pasta_entrada   = pasta_entrada   or M03_ENTRADA
    pasta_imagens   = pasta_imagens   or M03_IMAGENS
    modelo_kcor     = modelo_kcor     or M03_MODELO_KCOR
    pasta_saida     = pasta_saida     or M03_SAIDA
    pasta_fotos_pdf = pasta_fotos_pdf or M02_FOTOS_PDF
    pasta_fotos_nc  = pasta_fotos_nc  or M02_FOTOS_NC

    return _executar_em_pasta(
        pasta_entrada, "conservacao",
        pasta_imagens, pasta_fotos_pdf, pasta_fotos_nc,
        modelo_kcor, pasta_saida,
        forcar_fallback, callback_progresso,
    )


def executar_meio_ambiente(pasta_entrada: Path | None = None,
                            pasta_imagens: Path | None = None,
                            modelo_kcor:   Path | None = None,
                            pasta_saida:   Path | None = None,
                            forcar_fallback: bool = False,
                            callback_progresso=None) -> list[Path]:
    """
    Módulo 07: Meio Ambiente.
    Processa todos os .xlsx da pasta de entrada no modo 'meio_ambiente'.
    """
    pasta_entrada = pasta_entrada or M07_ENTRADA
    pasta_imagens = pasta_imagens or M07_IMAGENS
    modelo_kcor   = modelo_kcor   or M03_MODELO_KCOR
    pasta_saida   = pasta_saida   or M07_SAIDA

    return _executar_em_pasta(
        pasta_entrada, "meio_ambiente",
        pasta_imagens, None, None,
        modelo_kcor, pasta_saida,
        forcar_fallback, callback_progresso,
    )


def _executar_em_pasta(pasta_entrada: Path, modo: str,
                        pasta_imagens: Path,
                        pasta_fotos_pdf: Path | None,
                        pasta_fotos_nc: Path | None,
                        modelo_kcor: Path,
                        pasta_saida: Path,
                        forcar_fallback: bool,
                        callback_progresso) -> list[Path]:
    """Engine comum para os dois modos."""
    arquivos = sorted([
        f for f in pasta_entrada.glob("*.xlsx")
        if not f.name.startswith("~")
        and not f.name.startswith("_Processado")
        and not f.name.startswith("_")
        and "Relatório Fotográfico" not in f.name
    ])

    if not arquivos:
        logger.warning(f"Nenhum .xlsx encontrado em: {pasta_entrada}")
        return []

    label = "Conservação" if modo == "conservacao" else "Meio Ambiente"
    logger.info(f"Módulo 03/07 [{label}]: {len(arquivos)} arquivo(s).")

    gerados: list[Path] = []
    for idx, arq in enumerate(arquivos):
        if callback_progresso:
            callback_progresso(idx + 1, len(arquivos), f"[{label}] {arq.name[:55]}")

        gerado_kcor: list[Path | None] = [None]

        def _processar_com_copia(path_local: str):
            p = Path(path_local)
            res = _processar_arquivo(
                arq_path        = p,
                modo            = modo,
                pasta_imagens   = pasta_imagens,
                pasta_fotos_pdf = pasta_fotos_pdf or Path("."),
                pasta_fotos_nc  = pasta_fotos_nc,
                modelo_kcor     = modelo_kcor,
                pasta_saida     = pasta_saida,
                forcar_fallback = forcar_fallback,
            )
            gerado_kcor[0] = res
            # Arquivo de entrada é renomeado para _Processado - nome; copiar esse de volta
            path_renomeado = p.parent / f"_Processado - {p.name}"
            return str(path_renomeado) if path_renomeado.exists() else path_local

        try:
            processar_com_copia_local(arq, _processar_com_copia)
            if gerado_kcor[0]:
                gerados.append(gerado_kcor[0])
        except KeyError as e:
            if "Content_Types" in str(e):
                logger.error(f"Arquivo corrompido ou incompleto: {arq.name}. Remova e regenere pelo Módulo 02.")
            else:
                logger.error(f"Erro em {arq.name}: {e}", exc_info=True)
        except Exception as e:
            logger.error(f"Erro em {arq.name}: {e}", exc_info=True)

    logger.info(f"Módulo 03/07 [{label}] concluído: {len(gerados)} arquivo(s) gerado(s).")
    if callback_progresso:
        callback_progresso(len(arquivos), len(arquivos),
                           f"[{label}] Concluído: {len(gerados)} arquivo(s).")
    return gerados
