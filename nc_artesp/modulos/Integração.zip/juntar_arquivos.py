"""
modulos/juntar_arquivos.py
────────────────────────────────────────────────────────────────────────────
Equivalente VBA: Art_04_EAF_Rot_Juntar_Arquivo_Exportar_Kria
Desenvolvedor: Ozeias Engler

Consolida todos os .xlsx gerados em Arquivos/Conservação/ em uma planilha
acumulada única, acrescentando os registros ao final das linhas já existentes.

Colunas da planilha Kcor-Kria (A=1 ... Y=25):
  A: NumItem | B: Origem | C: Motivo | D: Classificação | E: Tipo
  F: Rodovia | G: KMi    | H: KMf    | I: Sentido       | J: Local
  K: Gestor  | L: Executor | M: Data Solicitação | N: Data Suspensão
  O: DtInicio_Prog | P: DtFim_Prog | Q: DtInicio_Exec | R: DtFim_Exec
  S: Prazo   | T: ObsGestor | U: Observações | V: Diretório
  W: Arquivos | X: Indicador | Y: Unidade (ou nº Kria após mod 05)
"""

import logging
from pathlib import Path

import openpyxl
from openpyxl import load_workbook

from config import M04_ENTRADA, M04_ACUMULADO, M04_SAIDA, CABECALHO_KCOR_KRIA, NUM_COLUNAS_KCOR_KRIA
from utils.helpers import garantir_pasta, caminho_dentro_limite_windows, timestamp_agora, parse_data, data_yyyymmdd

logger = logging.getLogger(__name__)

# Número total de colunas da planilha Kcor-Kria (compatível VBA)
NUM_COLUNAS = NUM_COLUNAS_KCOR_KRIA


def _ler_arquivo(caminho: Path) -> list[list]:
    """Lê todas as linhas de dados (a partir da linha 2) de um .xlsx."""
    wb = load_workbook(str(caminho), data_only=True)
    ws = wb.active

    linhas = []
    ultima = ws.max_row
    for r in range(2, ultima + 1):
        linha = [ws.cell(row=r, column=c).value for c in range(1, NUM_COLUNAS + 1)]
        # Só inclui linhas que tenham pelo menos col A preenchida
        if any(v is not None and str(v).strip() != "" for v in linha[:3]):
            linhas.append(linha)
    wb.close()
    return linhas


def executar(pasta_entrada: Path | None = None,
             arquivo_acumulado: Path | None = None,
             pasta_saida: Path | None = None,
             callback_progresso=None,
             arquivos_entrada: list[Path] | None = None) -> Path:
    """
    Consolida todos os .xlsx da pasta de entrada na planilha acumulada.

    Retorna o Path do arquivo acumulado salvo.
    """
    pasta_entrada    = pasta_entrada    or M04_ENTRADA
    arquivo_acumulado = arquivo_acumulado or M04_ACUMULADO
    pasta_saida      = pasta_saida      or M04_SAIDA
    garantir_pasta(pasta_saida)

    # ── Coletar arquivos de entrada ──────────────────────────────────────────
    if arquivos_entrada is not None:
        arquivos = sorted([
            Path(f) for f in arquivos_entrada
            if Path(f).exists()
            and Path(f).suffix.lower() == ".xlsx"
            and not Path(f).name.startswith("~")
            and "Acumulado" not in Path(f).name
            and not Path(f).name.startswith("_")
        ])
    else:
        arquivos = sorted([
            f for f in pasta_entrada.glob("*.xlsx")
            if not f.name.startswith("~")            # ignora temporários Excel
            and "Acumulado" not in f.name            # não processa o próprio acumulado
            and not f.name.startswith("_")
        ])

    if not arquivos:
        logger.warning(f"Nenhum .xlsx encontrado em: {pasta_entrada}")
        return None

    logger.info(f"Encontrados {len(arquivos)} arquivo(s) para consolidar.")

    # ── Ler todos os registros ───────────────────────────────────────────────
    todos_registros: list[list] = []
    for idx, arq in enumerate(arquivos):
        if callback_progresso:
            callback_progresso(idx + 1, len(arquivos), f"Lendo: {arq.name[:60]}")
        logger.info(f"Lendo: {arq.name}")
        registros = _ler_arquivo(arq)
        todos_registros.extend(registros)
        logger.info(f"  {len(registros)} registro(s) lido(s).")

    if not todos_registros:
        logger.warning("Nenhum registro encontrado nos arquivos.")
        return None

    logger.info(f"Total de registros a consolidar: {len(todos_registros)}")

    # ── Abrir ou criar planilha acumulada base ────────────────────────────────
    if not arquivo_acumulado.exists():
        garantir_pasta(arquivo_acumulado.parent)
        cab = list(CABECALHO_KCOR_KRIA)
        wb_novo = openpyxl.Workbook()
        ws_novo = wb_novo.active
        for c, v in enumerate(cab, start=1):
            ws_novo.cell(row=1, column=c).value = v
        wb_novo.save(str(arquivo_acumulado))
        logger.info(f"Arquivo base criado: {arquivo_acumulado.name}")

    wb_acum = load_workbook(str(arquivo_acumulado))
    ws_acum = wb_acum.active

    # Encontrar última linha com dados
    ultima = ws_acum.max_row
    for r in range(ultima, 0, -1):
        if ws_acum.cell(row=r, column=1).value is not None:
            ultima = r
            break
    else:
        ultima = 1  # só cabeçalho

    prox_linha = ultima + 1
    logger.info(f"Acumulado: última linha existente = {ultima}. Inserindo a partir de {prox_linha}.")

    # ── Escrever registros ───────────────────────────────────────────────────
    for idx, registro in enumerate(todos_registros):
        row = prox_linha + idx
        for col, valor in enumerate(registro, start=1):
            ws_acum.cell(row=row, column=col).value = valor

    # ── Determinar nome do arquivo de saída ──────────────────────────────────
    # Usa a data de solicitação do último registro (col M = índice 12)
    data_ref = None
    for reg in reversed(todos_registros):
        dt = parse_data(reg[12]) if len(reg) > 12 else None
        if dt:
            data_ref = dt
            break

    data_str = data_yyyymmdd(data_ref) if data_ref else timestamp_agora()[:8]
    nome_saida = f"{data_str} - {timestamp_agora()[9:]} - Eventos Acumulado Artesp para Exportar Kria.xlsx"
    destino = caminho_dentro_limite_windows(pasta_saida / nome_saida)
    garantir_pasta(destino.parent)

    wb_acum.save(str(destino))
    wb_acum.close()
    logger.info(f"Módulo 04 concluído. Acumulado salvo: {destino.name}")

    if callback_progresso:
        callback_progresso(len(arquivos), len(arquivos), "Módulo 04 concluído.")

    return destino
